setwd('/home2/s421955/projects/singlecellRNA/data/cytof_crispr/')
source('~/projects/singlecellRNA/code/facs_crispr_functions.R')
library(lattice)
library(reshape2)
library(gplots)
############0. load data
path='/home2/s421955/projects/singlecellRNA/data/cytof_crispr/stk4'
#cytof_mice=load_facs(path)
#save(cytof_mice,file='/home2/s421955/projects/singlecellRNA/data/cytof_crispr/stk4/stk4.RData')
load('/home2/s421955/projects/singlecellRNA/data/cytof_crispr/stk4/stk4.RData')
###########1. preprocess data and match to mice
cytof_mice=preprocessFacs(cytof_mice)
# signatures1=list(
#   'T cells'=c("FITC-A<CD3>","BV510-A<CD8>","BV785-A<CD4>"),
#   "B cells"=c("450/50 (325)-A<CD19>"),
#   'NK cells'=c("BV650-A<NK1-1>",'BV510-A<CD8>'),
#   'mDC cells'=c('BV711-A<CD11c>',"450/50 (325)-A<CD19>"),
#   'Macrophages/Neutrophils'=c("SSC-A<NA>","FSC-A<NA>")
# )
# signatures2=list("CD8 T cells"=c("BV510-A<CD8>",'low_BV650-A<NK1-1>'),"CD4 T cells"=c("BV785-A<CD4>",'low_BV650-A<NK1-1>'))
# signatures3=list("Macrophages"=c("PE-A<F4/80>"),"Neutrophils"=c("BV785-A<CD4>"))
# signatures4=list("Neutrophils"=c("FSC-H<NA>",'SSC-H<NA>'),"Macrophages"=c("FSC-H<NA>",'low_SSC-H<NA>'))

######signatures update July 14 2018 from TW
signatures1=list(
  'T cells'=c("FITC-A<CD3>","BV421-A<CD5>"),
  "B cells"=c("450/50 (325)-A<CD19>","low_APC-A<CD43>"),
  'NK cells'=c("BV650-A<NK1-1>"),
  'mDC cells'=c('BV711-A<CD11c>'),
  'Macrophages/Neutrophils'=c("SSC-A<NA>","FSC-A<NA>"))
signatures2=list("CD8 T cells"=c("BV510-A<CD8>"),
                 "CD4 T cells"=c("BV785-A<CD4>"))
signatures3=list("Macrophages"=c("PE-A<F4/80>","Alexa Fluor 700-A<CD45R>"),
                 "Neutrophils"=c('BV785-A<CD4>'))
###########2.SCENA
test=crisprSCINA(cytof_mice$facs,cytof_mice$ind,signatures1,signatures2,signatures3)
#cor=test_correlation(test$sorted,cytof_mice$ind)
#genoplot('Stk4',test,cytof_mice$facs,cytof_mice$ind,'~/temp/Stk4_pheno.pdf','~/temp/Stk4_projection.pdf')
#write.csv(cor,file='~/temp/Stk4_correlation.csv')
save(test,file='~/temp/tmp_stk4_SCENA_results.RData')
#########3. conbined bar plots
load('~/temp/tmp_stk4_SCENA_results.RData')
genotype=read.csv("/project/SCCC/Wang_lab/shared/SCINA/crispr_mice_genotypes.csv",stringsAsFactors = F)
genotype=genotype[genotype$symbol=='Stk4' & genotype$ear_tag %in% row.names(test$sorted),]
mutations=factor(genotype$genotype,levels=c("WT","HET","HOM"))
test$sorted=data.frame(test$sorted[genotype$ear_tag,],stringsAsFactors = F)
test$sorted=test$sorted*100
row.names(cytof_mice$ind)=cytof_mice$ind$ear_tag
cytof_mice$ind=cytof_mice$ind[genotype$ear_tag,]
test$sorted$B.cells=test$sorted$B1.cells+test$sorted$B2.cells
test$sorted$T.cells=test$sorted$CD4.T.cells+test$sorted$CD8.T.cells
cytof_mice$ind$B.cells=cytof_mice$ind$facs_b_cells
cytof_mice$ind$T.cells=cytof_mice$ind$facs_t_cells
cytof_mice$ind$NK.cells=cytof_mice$ind$facs_nk_cells

data2plot1=melt(cbind(test$sorted[,c('B.cells','T.cells','NK.cells')],mutations))
data2plot2=melt(cbind(cytof_mice$ind[,c('B.cells','T.cells','NK.cells')],mutations))
pval=anova(lm(data2plot1[data2plot1$variable=='B.cells',"value"]~as.factor(data2plot1[data2plot1$variable=='B.cells',"mutations"])))$'Pr(>F)'[1]
pval=anova(lm(data2plot2[data2plot2$variable=='B.cells',"value"]~as.factor(data2plot2[data2plot2$variable=='B.cells',"mutations"])))$'Pr(>F)'[1]
pdf('~/temp/SCENA_crisprresults.pdf',height=3,width=3.5)
par(xpd=T,mar=c(5,5,2,8))
boxplot(value~mutations+variable,data=data2plot1,at=c(1:3,5:7,9:11),xaxt='n',col=c('deepskyblue','darkseagreen1','gold'),xlab='SCENA results',ylab='Cell ratios %')
axis(side=1,at=c(2,6,10),label=c('B cells','T cells','NK cells'))
legend(x=14,y=0.4,legend=c('WT','HET','HOM'),fill=c('deepskyblue','darkseagreen1','gold'),cex=0.7)
dev.off()
pdf('~/temp/manual_crisprresults.pdf',height=3,width=3.5)
par(xpd=T,mar=c(5,5,2,8))
boxplot(value~mutations+variable,data=data2plot2,at=c(1:3,5:7,9:11),xaxt='n',col=c('deepskyblue','darkseagreen1','gold'),xlab='Manual gating results',ylab='Cell ratios %')
axis(side=1,at=c(2,6,10),label=c('B cells','T cells','NK cells'))
legend(x=14,y=0.4,legend=c('WT','HET','HOM'),fill=c('deepskyblue','darkseagreen1','gold'),cex=0.7)
dev.off()
#Neutrophils
pdf('~/temp/SCENA_NE.pdf',height=3,width=2)
boxplot(test$sorted$Neutrophils~mutations,col=c('deepskyblue','darkseagreen1','gold'),xlab='SCENA results',ylab='Neutrophil ratios %')
pval=anova(lm(test$sorted$Neutrophils~mutations))$'Pr(>F)'[1]
dev.off()
pdf('~/temp/manual_NE.pdf',height=3,width=2)
boxplot(cytof_mice$ind$facs_neutrophils~mutations,col=c('deepskyblue','darkseagreen1','gold'),xlab='Manual gating results',ylab='Neutrophil ratios %')
pval=anova(lm(cytof_mice$ind$facs_neutrophils~mutations))$'Pr(>F)'[1]
dev.off()
###Macrophages
pdf('~/temp/SCENA_MO.pdf',height=3,width=2)
boxplot(test$sorted$Macrophages~mutations,col=c('deepskyblue','darkseagreen1','gold'),xlab='SCENA results',ylab='Macrophage ratios %')
pval=anova(lm(test$sorted$Macrophages~mutations))$'Pr(>F)'[1]
dev.off()
pdf('~/temp/manual_MO.pdf',height=3,width=2)
boxplot(cytof_mice$ind$facs_macrophages~mutations,col=c('deepskyblue','darkseagreen1','gold'),xlab='Manual gating results',ylab='Macrophage ratios %')
pval=anova(lm(cytof_mice$ind$facs_macrophages~mutations))$'Pr(>F)'[1]
dev.off()

