#03/01/2018
#This script works as a comparision between cellranger and SCINA when analyzing cellranger datasets
#https://www.nature.com/articles/ncomms14049 68kPBMC dataset
#https://support.10xgenomics.com/single-cell-gene-expression/datasets CD14+ Monocytes to CD8+/CD45RA+ Naive Cytotoxic T Cells, raw gene matrix
rm(list=ls())
setwd('~/projects/singlecellRNA/data/cellrangerdatasets')
#source('~/projects/singlecellRNA/code/EM_model_tw.R')
source('/home2/s421955/projects/singlecellRNA/code/SCINA/R/EM_model.R')
source('/home2/s421955/projects/singlecellRNA/code/SCINA/R/EM_functions.R')
source('~/projects/singlecellRNA/code/realdatacp_functions.R')
source('/project/bioinformatics/Xiao_lab/s421955/projects/singlecellRNA/code/SNN.R')
load("~/projects/retrovirus/data/eTME_signatures_v5.RData")
library('biomaRt')
library('preprocessCore')
library('mclust')
library('reshape2')
library("cytofkit")
library('ggplot2')
library('scatterplot3d')
#########1. decide whether reload all csv matrices, convertion to HUGO ID and aggregation is in need. default=FALSE
#read_convert_datasets(path = '/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/tmp',name='batched_jurkat_293T.RData')
load('batched_jurkat_293T.RData')
jurkat_293T=batched_mat
load('batched_filtered_expmat.RData')
immune_cellranger=batched_mat
rm(batched_mat)
#batched_filtered_expmat shared the same gene list as row.names

###########2. Generate signature lists
signatures_eTME=list(`b_cells`=signatures[['B cells']],`cd14_monocytes`=signatures[['Monocytes']],
                     `cd4_t_helper`=c(signatures[['Th1 cells']],signatures[['Th2 cells']],signatures[['Th cells']]),
                     `cd56_nk`=c(signatures[['NK cells']],signatures[['CD56bright NK cells']]),
                     `cytotoxic_t`=signatures[['CD8 T cells']],`memory_t`=signatures[['Tm cells']],
                     `naive_cytotoxic`=signatures[['CD8 T cells']],`naive_t`=signatures[['CD8 T cells']],
                     `regulatory_t`=signatures[['Treg cells']])
#signatures_eTME[[c(7,8)]] are not valid now
#in complete sub signature lists for immune_cellranger
vec=1:2;len=rep.int(300,2);file='testSCINAoncellranger3.RData'
SCINA_truedata(vec,len,immune_cellranger,signatures_eTME,file)
##########6. Real data test on SCINA
#Mix cells from the dataset like cellranger did.
#Write cell mixtures back into cellranger h5 file.
#Compare with cellranger classification results.
###6.1 04/02/2018 use blueprint signatures, saved in singlecellRNA/data as blueprintsignatures.csv/blueprint.RData
load('~/projects/singlecellRNA/data/blueprint.RData')
blueprint_RPKM=data;rm(data)
signatures1=read.csv("/home2/s421955/projects/singlecellRNA/data/blueprintsignatures.csv",stringsAsFactors = F)
signatures_bluep=list()
#cell type markers based on cellranger FACS cell marker
namelist=list(
  b_cells=NA,
  cd14_monocytes="CD14.positive..CD16.negative.classical.monocyte",
  cd4_t_helper='CD4.positive..alpha.beta.T.cell',
  cd56_nk='cytotoxic.CD56.dim.natural.killer.cell',
  cytotoxic_t='CD8.positive..alpha.beta.T.cell',
  memory_t='effector.memory.CD4.positive..alpha.beta.T.cell',
  naive_cytotoxic='CD8.positive..alpha.beta.thymocyte',
  naive_t='CD4.positive..alpha.beta.thymocyte',
  regulatory_t='regulatory.T.cell'
)
length_list=c(0,50,50,100,100,100,120,150,150)
for(i in 2:length(immune_cellranger)){
  tmp=namelist[[i]]
  print(tmp)
  signatures_bluep[[i]]=names(head(blueprint_RPKM[order(blueprint_RPKM[,tmp],decreasing = T),tmp],n=length_list[i]))
  names(signatures_bluep)[i]=names(immune_cellranger)[i]
}
signatures_bluep[[1]]=signatures1$Symbol[signatures1$Cell.type=='B cells']
names(signatures_bluep)[1]='b_cells'
vec=c(1,2,4);len=rep.int(100,3);file='testSCINAoncellranger3.RData'
SCINA_truedata(vec,len,immune_cellranger,signatures_bluep[c(1,2,4)],file)
#b_cells, ch14_monocytes,cd59_nk are very good
load('testSCINAoncellranger3.RData')
table(results$cell_labels,exp_test$true_label)
#6.2 04/05/2018 signatures from 
#Schelker, Max, et al. "Estimation of immune cell content in tumour tissue using single-cell RNA-seq data."
#Nature communications 8.1 (2017): 2032.
signatures_nat17=list(
  b_cells=c('CD19', 'MS4A1', 'CD79A','CD79B', 'BLNK'),
  cd14_monocytes=c('CD14', 'CD68', 'CD163','CSF1R', 'FCGR3A'),
  cd4_t_helper=c('CD4',"RN7SL2","7SK"),
  cd56_nk=c('FCGR3A', 'FCGR3B','NCAM1', 'KLRB1', 'KLRB1','KLRC1', 'KLRD1', 'KLRF1','KLRK1'),
  cytotoxic_t=c('CD8B','CD8A'),
  memory_t=NA,
  naive_cytotoxic=NA,
  naive_t=NA,
  regulatory_t=c('FOXP3', 'IL2RA','CTLA4')
)
vec=c(1,2,4,5);len=rep.int(200,4);file='testSCINAoncellranger3.RData'
SCINA_truedata(vec,len,immune_cellranger,signatures_nat17[c(1,2,4,5)],file)
load('testSCINAoncellranger3.RData')
table(results$cell_labels,exp_test$true_label)
#6.3 04/19/2018 manually select clustered cells
vec=c(1,2,3,4,5,6,7,8,9);len=rep.int(500,9)
exp_test=mixexp(vec,len,immune_cellranger)
exp_pcaplot(vec,len,exp_test)
#6.4 04222018 import cybersort genes https://cibersort.stanford.edu/download.php
cybersig=read.table('~/projects/singlecellRNA/data/LM22.txt',header=T,sep='\t',stringsAsFactors = F)
load('~/projects/singlecellRNA/data/blueprint.RData')
signatures_cyber=signatures_nat17
signatures_cyber$cd4_t_helper=NA
genevectmp=c(8,6,10)
sigvectmp=c(6,8,9)
for(i in 1:3){
  signatures_cyber[[sigvectmp[i]]]=findgenesigs(cybersig,genevectmp[i])
}
vec=c(1,2,4,9);len=rep.int(300,4);file='testSCINAoncellranger3.RData'
SCINA_truedata(vec,len,immune_cellranger,signatures_cyber[vec],file)
load('testSCINAoncellranger3.RData')
table(results$cell_labels,exp_test$true_label)
#6.5 042518 use self_defined signatures
cells=c("b_cells","cd14_monocytes","cd4_t_helper","cd56_nk","cytotoxic_t",
        "memory_t","naive_t","regulatory_t")
signatures_selfdef=findgenesigs(immune_cellranger,cells,500,0.7)
for(i in length(immune_cellranger)){immune_cellranger[[i]]=immune_cellranger[[i]][,501:dim(immune_cellranger[[i]])[2]]}
vec=c(match(names(signatures_selfdef),names(immune_cellranger)),9)#use the last one as 'unknown' cell type
len=rep.int(100,length(vec))
file='testSCINAoncellranger3.RData'
names(immune_cellranger)[9]='unknown'
SCINA_truedata(vec,len,immune_cellranger,signatures_selfdef,file)
load('testSCINAoncellranger3.RData')
tmp=table(results$cell_labels,exp_test$true_label)
colnames(tmp)=row.names(tmp)=c('B cells','Monocytes','Natural killer cells','Unknown')
#pdf('~/projects/singlecellRNA/data/cr_heatmap.pdf',height=5,width=5)
#heatmap.2(tmp,trace='none',cellnote = tmp,notecol='black',col=c('azure2',brewer.pal(7,'YlOrRd')),density.info='none',breaks=c(0,0.1,10,30,50,100,150,200,300),
##dev.off()
pdf('~/temp/Fig4_cellranger.pdf',height=4,width=3)
stack2plot=table(results$cell_labels,exp_test$true_label)
stack2plot_percent=apply(stack2plot,2,function(x){x*100/sum(x,na.rm=T)})
par(xpd = T, mar = par()$mar + c(0,0,0,4))
barplot(stack2plot_percent,col=c('deepskyblue','aquamarine','goldenrod1','grey64'),border='white',xlab='True labels',xaxt='n',ylab='Predicted labels %')
axis(side=1,at=c(1:dim(stack2plot_percent)[2])*1.2-0.5,labels=NA)
text(x=c(1:dim(stack2plot_percent)[2])*1.2-0.5,y=-7,srt=45,adj=1,xpd=TRUE,labels=c('B cells','Monocytes','NK cells','Unknown'),cex = 0.8)
legend(x=5,y=90,legend=c('B cells','Monocytes','NK cells','Unknown'),fill=c('deepskyblue','aquamarine','goldenrod1','grey64'),cex=0.8)
#par(mar=c(5, 4, 4, 2) + 0.1)
dev.off()
#6.6 051318 use jurkat and 293T cells from GEO
cells=names(jurkat_293T)=c('293T','jurkat')
load('~/projects/singlecellRNA/data/sigs_jk_293T.RData')
#for(i in 1:length(signatures_selfdef)){signatures_selfdef[[i]]=signatures_selfdef[[i]][1:20]}
vec=c(1,2);len=c(1000,1000);file='testSCINAoncellranger4.RData'
SCINA_truedata(vec,len,jurkat_293T,signatures_Jk_293T,file)
#exp_test=mixexp(vec,len,jurkat_293T)
#exp_pcaplot(vec,len,exp_test)
load('testSCINAoncellranger4.RData')
table(results$cell_labels,exp_test$true_label)
#mix from 1:9 to 9:1
total=2000
acc=c()
ari=c()
for(i in 1:99){
  vec=c(1,2)
  len=c(total*i/100,total*(100-i)/100)
  print(len)
  exp_test=mixexp(vec,len,jurkat_293T)
  results=try(SCINA(exp_test$exp_data,signatures_Jk_293T,max_iter=100,convergence_n=10,
  convergence_rate=0.99,sensitivity_cutoff = 0.33))
  acc[[i]]=table(results$cell_labels==exp_test$true_label)['TRUE']/length(exp_test$true_label)
  ari[[i]]=adjustedRandIndex(results$cell_labels,exp_test$true_label)
}
save(acc,ari,file='~/projects/singlecellRNA/data/293T_jk_results_083018.RData')
load('~/projects/singlecellRNA/data/293T_jk_results_083018.RData')
SCINA_acc=acc
SCINA_ari=ari
#load('~/projects/singlecellRNA/data/mix293T_jurk_result_cellranger.RData')
load('~/projects/singlecellRNA/data/mix293T_jurk_result_cellranger_2clusters.RData')
cr_acc=matrix(0,ncol=9,nrow=99);cr_ari=matrix(0,ncol=9,nrow=99)
colnames(cr_acc)=colnames(cr_ari)=paste('Km',2:10,'clusters',sep='_')
row.names(cr_acc)=row.names(cr_ari)=1:99
for(i in 1:99){
  for(j in 1:2){
    if(is.na(acc1[[i]][j])){acc1[[i]][j]=0}
    if(is.na(acc2[[i]][j])){acc2[[i]][j]=0}
    cr_acc[i,j]=max(as.numeric(acc1[[i]][j]),as.numeric(acc2[[i]][j]))
    cr_ari[i,j]=as.numeric(ari[[i]][j])
  }
}
#083118 add lines of SNN clustering
ari_SNN=c()
for(i in 1:99){
  python_out=paste('/home2/s421955/temp/SNN_outs/',i,'_hekout.txt',sep='')
  outtmp=read.csv(python_out,stringsAsFactors = F,header=F)
  len=c(total*i/100,total*(100-i)/100)
  true_label=c(rep(1,len[1]),rep(2,len[2]))
  ari_SNN[i]=adjustedRandIndex(outtmp$V1,true_label)
}
plot_sub_293T_jk=function(name,height,y1,y2,ylim,col,legend){
  #y1: vector of SCINA acc/ari
  #y2: matrix of cell ranger acc/ari, default 99 rows (ratios), 9 columns (clusters) 
  #col: vector of cols, length equals to dim(y2)[2]
  pdf(name,height=height,width=9)
  par(xpd=T,mar=c(4,4,4,10))
  plot(x=1:99/100,y=y1,type='l',lty=1,lwd=2,col=col[1],xaxt='n',yaxt='n',ylim=ylim,xlab='Ratio of 293T cells',ylab=NA)
  for(i in 1:dim(y2)[2]){
    lines(x=1:99/100,y=y2[,i],type='l',lty=2,lwd=2,col=col[i])
  }
  legend(1.05,1,legend = legend,col=c(col[1],col),lty=c(1,rep(2,dim(y2)[2]+1)),lwd=2,bty='n',cex=0.6)
  axis(side=1,at=seq(0.01,0.99,0.1),labels=paste(seq(1,99,10),'%',sep=''),cex=0.5,srt=45)
  axis(side=2,at=c(0:11)/10,labels=c(0:11)/10,cex=0.5,srt=45)
  dev.off()
}
plot_sub_ari_293T_jk=function(name,height,y1,y2,y3,ylim,col,legend){
  #y1: vector of SCINA acc/ari
  #y2: matrix of cell ranger acc/ari, default 99 rows (ratios), 9 columns (clusters) 
  #col: vector of cols, length equals to dim(y2)[2]
  pdf(name,height=height,width=9)
  par(xpd=T,mar=c(4,4,4,10))
  plot(x=1:99/100,y=y1,type='l',lty=1,lwd=2,col=col[1],xaxt='n',yaxt='n',ylim=ylim,xlab='Ratio of 293T cells',ylab=NA)
  for(i in 1:dim(y2)[2]){
    lines(x=1:99/100,y=y2[,i],type='l',lty=2,lwd=2,col=col[i])
  }
  lines(x=1:99/100,y=y3,type='l',lty=2,lwd=2,col='darkorange')
  legend(1.05,1,legend = legend,col=c(col[1],col,'darkorange'),lty=c(1,rep(2,dim(y2)[2]+1)),lwd=2,bty='n',cex=0.6)
  axis(side=1,at=seq(0.01,0.99,0.1),labels=paste(seq(1,99,10),'%',sep=''),cex=0.5,srt=45)
  axis(side=2,at=c(0:11)/10,labels=c(0:11)/10,cex=0.5,srt=45)
  dev.off()
}
ind=1#index of clusters wish to plot in cell ranger
plot_sub_293T_jk('~/temp/293_JK_acc.pdf',4,SCINA_acc,cr_acc[,ind,drop=F],c(0.5,1.1),rainbow(dim(cr_acc[,ind,drop=F])[2]),c('SCINA Accuracy',paste('Cell Ranger',(ind+1),'clusters','Accuracy')))
plot_sub_ari_293T_jk('~/temp/293_JK_SNN_ari.pdf',4,SCINA_ari,cr_ari[,ind,drop=F],ari_SNN,c(0,1.1),rainbow(dim(cr_acc[,ind,drop=F])[2]),c('SCINA ARI',paste('Cell Ranger',(ind+1),'clusters','ARI'),'SNN-Cliq'))
#6.7 kidney internal dataset
load('jim_scRNA.RData')
cells=names(jim_scRNA)
signatures_selfdef=findgenesigs(jim_scRNA,cells,150,3)
for(i in length(jim_scRNA)){jim_scRNA[[i]]=jim_scRNA[[i]][,151:dim(jim_scRNA[[i]])[2]]}
vec=c(1,2);len=c(300,300);file='testSCINAoncellranger5.RData'
exp_test=mixexp(vec,len,jim_scRNA)
exp_pcaplot(vec,len,exp_test)
SCINA_truedata(vec,len,jim_scRNA,signatures_selfdef,file)
load('testSCINAoncellranger5.RData')
tmp=table(results$cell_labels,exp_test$true_label)
pdf('~/projects/singlecellRNA/data/jim_kidney.pdf',height=4,width=4)
heatmap.2(tmp,trace='none',cellnote = tmp,notecol='black',col=c('azure2',brewer.pal(7,'YlOrRd')),density.info='none',breaks=c(0,0.1,10,30,50,100,150,200,300),
          notecex=0.8,dendrogram='none',Rowv=FALSE,Colv=FALSE,xlab='True label',ylab='Predicted label',cexRow = 0.8,cexCol = 0.8,margins = c(6,6))
dev.off()


