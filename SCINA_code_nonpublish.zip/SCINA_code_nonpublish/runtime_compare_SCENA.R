#! 07112018 Ze Zhang
#! This script is to measure SCINA running time difference comparing tSNE and cellranger
setwd('~/projects/singlecellRNA/data')
library('preprocessCore')
library('mclust')
#1. prepare data and signatures
load("/project/SCCC/Wang_lab/shared/cellranger_scRNA/batched_jurkat_293T.RData")
hek293=read.table("/project/SCCC/Wang_lab/shared/tmp/293_vs_jurkat/GSM2693929_HEK293_siGFP_control.count_RPKM.txt",stringsAsFactors = F,header=T, sep="\t")
jurkat=read.table("/project/SCCC/Wang_lab/shared/tmp/293_vs_jurkat/GSE69511_CBAPs-FPKM_values_data.txt",stringsAsFactors = F,header=T, sep="\t")
hek293=hek293[hek293$GeneName %in% jurkat$Name,]
rownames(jurkat)=jurkat$Name
jurkat=jurkat[hek293$GeneName,]
define_sig=data.frame(gene=hek293$GeneName,
                      hek293=hek293$RPKM,jurkat=apply(jurkat[,grepl("CBAP",colnames(jurkat))],1,mean),
                      stringsAsFactors = F)
define_sig$hek293=define_sig$hek293/mean(define_sig$hek293)
define_sig$jurkat=define_sig$jurkat/mean(define_sig$jurkat)
define_sig=define_sig[define_sig$gene %in% rownames(batched_mat[[1]]),]
signatures_Jk_293T=list("293T"=define_sig$gene[(define_sig$hek293+1)/(define_sig$jurkat+1)>20],
                        "jurkat"=define_sig$gene[(define_sig$jurkat+1)/(define_sig$hek293+1)>20])
#2. SCINA
source("~/projects/singlecellRNA/code/SCINA/R/EM_functions.R")
source("~/projects/singlecellRNA/code/SCINA/R/EM_model.R")
max_iter=100
convergence_n=20
convergence_rate=0.99
sensitivity_cutoff=1
acc_SCINA=c()
ari_SCINA=c()
time_SCINA=c()
for(i in 1:10){
  #use i*280, at most 2k hek293 cells, i*320, at most 3k jurkat cells
  print(i)
  exp_data=log(cbind(batched_mat[[1]][,sample(1:dim(batched_mat[[1]])[2], size = i*280, replace = FALSE)],
                     batched_mat[[2]][,sample(1:dim(batched_mat[[2]])[2], size = i*320, replace = FALSE)])+1)
  exp_data[]=normalize.quantiles(exp_data)
  start_time=Sys.time()
  results=SCINA(exp_data,signatures_Jk_293T,max_iter,convergence_n,convergence_rate,sensitivity_cutoff)
  end_time=Sys.time()
  true_label=c(rep("293T",i*280),rep("jurkat",i*320))
  acc_SCINA[[i]]=table(results$cell_labels==true_label)[2]/length(true_label)
  ari_SCINA[[i]]=adjustedRandIndex(results$cell_labels,true_label)
  time_SCINA[[i]]=end_time-start_time
}
save(acc_SCINA,ari_SCINA,time_SCINA,file='SCINA_runtime.RData')
