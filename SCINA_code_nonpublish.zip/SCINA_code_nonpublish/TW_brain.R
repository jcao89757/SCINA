#########  read data  #################

# read data
library("R.matlab")
library('preprocessCore')
# https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE110823
brain=readMat("/project/SCCC/Wang_lab/shared/SCINA/GSM3017261_150000_CNS_nuclei.mat")
brain_exp=brain$DGE
genes=brain$genes
sample_type=brain$sample.type
cluster_assignment=brain$cluster.assignment
cluster_assignment=strsplit(cluster_assignment," ")
rm(brain)

# keep only non-neuronal subtype
keep=sapply(cluster_assignment,function(x) x[[1]]) %in% as.character(55:73)
sample_type=sample_type[keep]
cluster_assignment=cluster_assignment[keep]
brain_exp=brain_exp[which(keep),]
brain_exp=t(as.matrix(brain_exp))
brain_exp=log(brain_exp+1)
rownames(brain_exp)=trimws(genes[,1],"both")
brain_exp=brain_exp[apply(brain_exp,1,sd)>0,]
brain_exp[]=normalize.quantiles(brain_exp)

#########  SCENA  ###############

# the original paper's classification
cluster_assignment=sapply(cluster_assignment,function(tmp) {
  tmp=tmp[tmp!=""]
  tmp[2]
})
cluster_assignment[cluster_assignment %in% c("Macrophage","Microglia")]="Macrophage/Microglia"
cluster_assignment[cluster_assignment %in% c("SMC","Endothelia")]="SMC/Endothelia"
cluster_assignment[cluster_assignment %in% c("Astro","Bergmann")]="Astro/Bergmann"
table(cluster_assignment)

# define signature genes, 
# took a special approach to expand from one gene to a set of geness
expan_sig<-function(exp_data,gene,rank_cutoff=50)
{
  cat(paste("Expansion for",gene,"\n"))
  cors=cor(exp_data[gene,],t(exp_data))[1,]
  names(cors)[rank(-cors)<=rank_cutoff]
}

signatures=list(
  "Oligo"=expan_sig(brain_exp,"Mbp"),
  "OPC"=expan_sig(brain_exp,"Pdgfra"),
  "Macrophage/Microglia"=expan_sig(brain_exp,"Dock2"),
  "SMC/Endothelia"=expan_sig(brain_exp,"Rgs5"),
  "VLMC"=expan_sig(brain_exp,"Col1a2"),
  "Astro/Bergmann"=expan_sig(brain_exp,"Aldh1l1"),
  "Ependyma"=expan_sig(brain_exp,"Dnah11"),
  "OEC"=expan_sig(brain_exp,"Mybpc1")
)

# SCENA
source('~/projects/singlecellRNA/code/EM_model_tw.R')
max_iter=100;convergence_n=10;convergence_rate=0.99;sensitivity_cutoff=1
results=SCINA(brain_exp,signatures,max_iter,convergence_n,convergence_rate,sensitivity_cutoff)
sum(results$cell_labels==cluster_assignment)/length(cluster_assignment)
table(results$cell_labels,cluster_assignment)

#########  t-SNE  #####################

# t-SNE
library("Rtsne")
brain_exp_sd=apply(brain_exp,1,sd)

for (sd_cutoff in c(0,0.3,0.6,0.9))
{
  print(sd_cutoff)
  set.seed(sd_cutoff)
  brain_tsne=Rtsne(t(brain_exp[brain_exp_sd>quantile(brain_exp_sd,sd_cutoff),]),
                   dims=2,theta=1,verbose=T)
  
  pdf(file=paste("~/temp/tSNE_brain_",sd_cutoff,".pdf",sep=""))
  cols=c("red","blue","cyan","green","orange","yellow","pink","black","grey")
  plot(brain_tsne$Y[,1],brain_tsne$Y[,2],pch=19,col=cols[as.numeric(factor(cluster_assignment,levels=names(signatures)))],
       xlab="t-SNE1",ylab="t-SNE2",cex=0.1)
  plot(brain_tsne$Y[,1],brain_tsne$Y[,2],pch=19,col=cols[as.numeric(factor(results$cell_labels,levels=c(names(signatures),"unknown")))],
       xlab="t-SNE1",ylab="t-SNE2",cex=0.1)
  dev.off()
}
