library('gplots')
library('RColorBrewer')
#simulation of bimodal distribution
mu1=log(10)
mu2=log(1000)
sig1=log(3)
sig2=log(3)
cpct=0.4
bimodalDistFunc=function(n,cpct,mu1,mu2,sig1,sig2){
  y0=rlnorm(n,mean=mu1,sd=sig1)
  y1=rlnorm(n,mean=mu2,sd=sig2)
  flag=rbinom(n,size=1,prob=cpct)
  y2=y0*(1-flag)+y1*flag
  y0=y0*(1-flag)
  y0=y0[y0>0]
  y1=y1*flag
  y1=y1[y1>0]
  y2=c(y2,y0,y1)
  return(list(y0,y1,y2))
}
bimodaldata=bimodalDistFunc(10000,cpct,mu1,mu2,sig1,sig2)
bimodaldata=lapply(bimodaldata,log)
pdf('~/temp/concept_density.pdf',height=5,width=4)
plot(density(bimodaldata[[3]]),xaxt='n',yaxt='n',xlab='Expression level',ylab='Frequency',ylim=c(0,0.4),lwd=2,col='black',main=NA)
axis(side=2,at=seq(0,0.3,0.03),labels = seq(0,0.5,0.05))
lines(density(bimodaldata[[1]]),lwd=2,lty=2,col='blue')
lines(density(bimodaldata[[2]]),lwd=2,lty=2,col='red')
dev.off()
#simulate heatmap
siggenes=sample(1:5,size=3,replace = T)
sigcells=sample(1:10,size=3,replace = T)
heat=matrix(0,ncol=sum(sigcells),nrow=sum(siggenes))
heatrow=1;heatcol=1
for(i in 1:length(sigcells)){
  heat[heatrow:(heatrow+siggenes[i]-1),heatcol:(heatcol+sigcells[i]-1)]=matrix(rnorm(siggenes[i]*sigcells[i],30,10),nrow=siggenes[i],ncol = sigcells[i])
  heatrow=heatrow+siggenes[i]
  heatcol=heatcol+sigcells[i]
}
mask=matrix(rnorm(dim(heat)[1]*dim(heat)[2],4,4),nrow=dim(heat)[1],ncol=dim(heat)[2])
heat[sample(siggenes[1]:dim(heat)[1],size=3),sample(sigcells[1]:dim(heat)[2],size=10)]=27
heat[heat==0]=mask[heat==0]
pdf('~/temp/concept_heat_2.pdf',height=5,width=6)
labRow=c(paste('Gene',1:(dim(heat)[1]-4)),'...',paste('Gene','i-2'),paste('Gene','i-1'),paste('Gene','i'))
labCol=c(paste('Cell',1:(dim(heat)[2]-4)),'...',paste('Cell','j-2'),paste('Gene','j-1'),paste('Gene','j'))
heatmap.2(heat,trace='none',col=c('white',brewer.pal(7,'Reds')),breaks=c(-10,0.1,5,10,20,25,30,45,60),density.info='none',
          dendrogram='none',Rowv=FALSE,Colv=FALSE,xlab=NA,ylab=NA,cexRow = 0.7,
          labRow =labRow,cexCol=0.7,labCol = labCol,margins=c(6.5,6.5),sepwidth = c(0.01,0.01),
          sepcolor = 'white',colsep = 1:ncol(heat),rowsep=1:nrow(heat))
dev.off()
#simulate tsne
iris_unique <- unique(iris) # Remove duplicates
iris_matrix <- as.matrix(iris_unique[,1:4])
iris_mattest=iris_matrix+matrix(runif(dim(iris_matrix)[1]*dim(iris_matrix)[2], -0.5, 0.5), dim(iris_matrix)[1])
iris2plot=rbind(iris_matrix,iris_mattest)
set.seed(42) # Set a seed if you want reproducible results
tsne_out <- Rtsne(iris2plot) # Run TSNE
# Show the objects in the 2D tsne representation
pdf('~/temp/simulate_tsne.pdf',height=4,width=4)
col_tsne=c('lightpink','lightskyblue','firebrick')
plot(tsne_out$Y,col=col_tsne[as.factor(c(iris_unique$Species,iris_unique$Species))],pch=19,cex=0.7,xlab='t-SNE 1',ylab='t-SNE 2')
dev.off()
