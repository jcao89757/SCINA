##########  prepare data  ###############

load("/project/SCCC/Wang_lab/shared/tmp/exp_mat.RData")
source('/project/SCCC/Wang_lab/shared/tmp/EM_model.R')
exp=exp[,apply(exp,2,mean)>(2.5)]
substr(info$type,1,1)=toupper(substr(info$type,1,1))
info$id=paste("id",1:dim(info)[1],sep="")
info[info$type=="Chromophobe","col"]="#EEAD0E"

# correct some errors in documentation
i=which((info$pat=="XP643" & info$type=="FHD-like") | info$type %in% "CIMP")
info[i,"type"]="Papillary"
info[i,"col"]="#9400D3"
info[i,"cex"]=0.3

i=which(grepl("TCGA.B0.5098.01",info$pat))
info[i,"type"]="Clear cell"
info[i,"col"]="#00FFFF"
info[i,"cex"]=0.3

annotations[[1]]$text="FHD"
annotations[[2]]$text="FHD-like"
annotations[[3]]$text="Papillary"
annotations[[5]]$text="Chromophobe"
annotations[[5]]$font$color="#EEAD0E"
annotations=annotations[-6]
annotations[[6]]$text="Clear cell"
annotations[[6]]$y=0.3

#########  SCINA  ##############

select_gene_sig<-function(keep,exp)
{
  tmp=apply(exp[keep,],2,mean)-apply(exp[!keep,],2,mean)  
  tmp=tmp[order(-tmp)]
  tmp=tmp[1:20]
  names(tmp[tmp>0])
}

signatures=list(
  "Clear cell"=select_gene_sig(info$type=="Clear cell",exp),
  "Chromophobe"=select_gene_sig(info$type=="Chromophobe",exp),
  "HLRCC"=select_gene_sig(info$type=="FHD",exp),
  "Normal"=select_gene_sig(info$type=="Normal",exp),
  "Papillary"=select_gene_sig(info$type %in% c("Papillary","FHD-like"),exp)
)

results=SCINA(t(exp),signatures,max_iter=100,convergence_n=10,convergence_rate=0.99,
              sensitivity_cutoff=1,rm_overlap=T)
substr(results$cell_labels,1,1)=toupper(substr(results$cell_labels,1,1))

#########  plot  #############

# HLRCC-like
confusion_matrix=table(info$type,results$cell_labels)
confusion_matrix
write.csv(confusion_matrix,file="/project/SCCC/Wang_lab/shared/tmp/HLRCC.csv")
View(info[info$type=="FHD-like" & results$cell_labels=="HLRCC",])

# Previous reports show there are 15 TCGA chRCC tumors that are wrongly classified as ccRCCs
# https://www.cell.com/cell-reports/fulltext/S2211-1247(18)30436-4
View(info[info$type=="Clear cell" & results$cell_labels=="Chromophobe",])
list1=info$id[info$type=="Clear cell" & results$cell_labels=="Chromophobe" & info$source=="TCGA"]

Ricketts=read.csv("/project/SCCC/Wang_lab/shared/tmp/mmc2.csv",stringsAsFactors = F)
list2=(info[info$type=="Clear cell" & gsub("\\.","-",substr(info$pat,1,12)) %in% 
  Ricketts$bcr_patient_barcode[Ricketts$PanKidney.Pathology=="ChRCC"],"id"])

table(list1 %in% list2)

# 3d PCA plot
library("plotly")
library("gplots")
library("dendextend")

p_exp=plot_ly(as.data.frame(pca_exp),x=~PC1,y=~PC2,z=~PC3,type="scatter3d",hoverinfo="text",
  mode="markers",marker=list(color=info$col,size=info$cex*20,symbol=info$pch,line=list(width=0),
  opacity=1),text="")
p_exp=layout(p_exp,annotations=annotations)
p_exp


