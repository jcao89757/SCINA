#########  read data  #################
setwd('~/projects/singlecellRNA/data')
# read data
library("R.matlab")
library('vioplot')
library('reshape2')
library('preprocessCore')
# https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE110823
brain=readMat("/project/SCCC/Wang_lab/shared/SCINA/GSM3017261_150000_CNS_nuclei.mat")
brain_exp=brain$DGE
genes=brain$genes
sample_type=brain$sample.type
cluster_assignment=brain$cluster.assignment
cluster_assignment=strsplit(cluster_assignment," ")
rm(brain)

# keep only non-neuronal subtype
keep=sapply(cluster_assignment,function(x) x[[1]]) %in% as.character(55:73)
sample_type=sample_type[keep]
cluster_assignment=cluster_assignment[keep]
brain_exp=brain_exp[which(keep),]
brain_exp=t(as.matrix(brain_exp))
brain_exp=log(brain_exp+1)
rownames(brain_exp)=trimws(genes[,1],"both")
brain_exp=brain_exp[apply(brain_exp,1,sd)>0,]
brain_exp[]=normalize.quantiles(brain_exp)

#########  SCINA  ###############

# the original paper's classification
cluster_assignment=sapply(cluster_assignment,function(tmp) {
  tmp=tmp[tmp!=""]
  tmp[2]
})
cluster_assignment[cluster_assignment %in% c("Macrophage","Microglia")]="Macrophage/Microglia"
cluster_assignment[cluster_assignment %in% c("SMC","Endothelia")]="SMC/Endothelia"
cluster_assignment[cluster_assignment %in% c("Astro","Bergmann")]="Astro/Bergmann"
table(cluster_assignment)

# define signature genes, 
# took a special approach to expand from one gene to a set of geness
expan_sig<-function(exp_data,gene,rank_cutoff=50)
{
  cat(paste("Expansion for",gene,"\n"))
  cors=cor(exp_data[gene,],t(exp_data))[1,]
  names(cors)[rank(-cors)<=rank_cutoff]
}

signatures=list(
  "Oligo"=expan_sig(brain_exp,"Mbp"),
  "OPC"=expan_sig(brain_exp,"Pdgfra"),
  "Macrophage/Microglia"=expan_sig(brain_exp,"Dock2"),
  "SMC/Endothelia"=expan_sig(brain_exp,"Rgs5"),
  "VLMC"=expan_sig(brain_exp,"Col1a2"),
  "Astro/Bergmann"=expan_sig(brain_exp,"Aldh1l1"),
  "Ependyma"=expan_sig(brain_exp,"Dnah11"),
  "OEC"=expan_sig(brain_exp,"Mybpc1")
)

# SCINA
source('/home2/s421955/projects/singlecellRNA/code/EM_model_tw_backup061718.R')
max_iter=100;convergence_n=10;convergence_rate=0.99;sensitivity_cutoff=1
results=SCENA(brain_exp,signatures,max_iter,convergence_n,convergence_rate,sensitivity_cutoff,rm_overlap = T)
sum(results$cell_labels==cluster_assignment)/length(cluster_assignment)
table(results$cell_labels,cluster_assignment)

#########  t-SNE  #####################

# t-SNE
##########jump this step, unreproducible, may because of Rcpp version problem. 
# library("Rtsne")
# brain_exp_sd=apply(brain_exp,1,sd)
# 
# for (sd_cutoff in c(0,0.3,0.6,0.9))
# {
#   print(sd_cutoff)
#   set.seed(sd_cutoff)
#   brain_tsne=Rtsne(t(brain_exp[brain_exp_sd>quantile(brain_exp_sd,sd_cutoff),]),
#                    dims=2,theta=1,verbose=T)
#   
#   pdf(file=paste("~/temp/tSNE_brain_",sd_cutoff,".pdf",sep=""))
#   cols=c("red","blue","cyan","green","orange","yellow","pink","black","grey")
#   plot(brain_tsne$Y[,1],brain_tsne$Y[,2],pch=19,col=cols[as.numeric(factor(cluster_assignment,levels=names(signatures)))],
#        xlab="t-SNE1",ylab="t-SNE2",cex=0.1)
#   plot(brain_tsne$Y[,1],brain_tsne$Y[,2],pch=19,col=cols[as.numeric(factor(results$cell_labels,levels=c(names(signatures),"unknown")))],
#        xlab="t-SNE1",ylab="t-SNE2",cex=0.1)
#   dev.off()
# }
############marker gene expression###########
load('/home2/s421955/projects/singlecellRNA/data/brain_tsne_0.9.RData')
results$cell_labels[results$cell_labels=='unknown'&brain_tsne$Y[,2]<10]='unknown2'
############probability plot############
library(ggplot2)
data2plot=as.data.frame(brain_tsne$Y,stringsAsFactors = F)
colnames(data2plot)=c('t_SNE1','t_SNE2')
data2plot$`prob_OPC`=results$probabilities['OPC',]
data2plot$`prob_Oligo`=results$probabilities['Oligo',]
data2plot$`prob_Unknown`=as.numeric(1-apply(results$probabilities,2,sum))
ggplot(data=data2plot,aes(x=t_SNE1,y=t_SNE2,color=prob_OPC))+geom_point(size=0.5)+scale_color_gradient(low="gray88", high="blue")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggsave('~/temp/OPC_prob.pdf',height=10,width=10)
ggplot(data=data2plot,aes(x=t_SNE1,y=t_SNE2,color=prob_Oligo))+geom_point(size=0.5)+scale_color_gradient(low="gray88", high="red")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                                                                                                                                panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggsave('~/temp/oligo_prob.pdf',height=10,width=10)
ggplot(data=data2plot,aes(x=t_SNE1,y=t_SNE2,color=prob_Unknown))+geom_point(size=0.5)+scale_color_gradient(low="gray88", high="gray33")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                                                                                                                                panel.background = element_blank(), axis.line = element_line(colour = "black"))
ggsave('~/temp/Unknown_prob.pdf',height=10,width=10)
##########gene's violin plot
vioplot_SCINA=function(brain_exp,gene,file){
  SCINA2plot=brain_exp[gene,results$cell_labels%in%c('OPC','Oligo','unknown'),drop=F]
  colnames(SCINA2plot)=results$cell_labels[results$cell_labels%in%c('OPC','Oligo','unknown')]
  x1=SCINA2plot[1,colnames(SCINA2plot)=='OPC']
  x2=SCINA2plot[1,colnames(SCINA2plot)=='Oligo']
  x3=SCINA2plot[1,colnames(SCINA2plot)=='unknown']
  pdf(file,height=3.5,width=4)
  par(las=2)
  par(mar=c(10,4,1,1))
  plot(1,1,xlim=c(0,4),ylim=range(SCINA2plot),type='n',ylab=gene,xlab=NA,xaxt='n',cex=0.6)
  axis(side = 1, at=c(1,2,3),label=c('OPCs','Intermediate cells','Oligodendrocytes'),cex=0.6)
  vioplot(x1,at=1,col="blue",add=TRUE)
  vioplot(x3,at=2,col="grey",add=TRUE)
  vioplot(x2,at=3,col="red",add=TRUE)
  dev.off()
}
vioplot_SCINA(brain_exp,'Mbp','~/temp/vioplot_oligomarker.pdf')
vioplot_SCINA(brain_exp,'Pdgfra','~/temp/vioplot_opcmarker.pdf')

#########find markers for unknown cells##########
Unknown_mean=apply(brain_exp[,results$cell_labels=='unknown'],1,mean)
OPC_mean=apply(brain_exp[,results$cell_labels=='OPC'],1,mean)
Oligo_mean=apply(brain_exp[,results$cell_labels=='Oligo'],1,mean)

cutoff=0.7 #cutoff used to be 0.1
all_genes=rownames(brain_exp)
Unknown_sig_genes=all_genes[Unknown_mean>OPC_mean+cutoff & Unknown_mean>Oligo_mean+cutoff]
Oligo_sig_genes=all_genes[Oligo_mean>OPC_mean+cutoff & Oligo_mean>Unknown_mean+cutoff]
OPC_sig_genes=all_genes[OPC_mean>Oligo_mean+cutoff & OPC_mean>Unknown_mean+cutoff]
write.table(all_genes,file='~/temp/background_genes.txt',row.names=FALSE,quote=FALSE)
write.table(Unknown_sig_genes,file='~/temp/testgenes_unknown.txt',row.names=FALSE,quote=FALSE)
write.table(Oligo_sig_genes,file='~/temp/testgenes_oligo.txt',row.names=FALSE,quote=FALSE)
write.table(OPC_sig_genes,file='~/temp/testgenes_OPC.txt',row.names=FALSE,quote=FALSE)
#https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3874087/
#phospholipid synthesis and myelination
test1=c('Dgat2', 'Cds1', 'Elovl7', 'Chka', 'Opalin', 'Qk', 'Pllp')
#axon repulsive guidance
test2=c('Sema4b', 'Sema6a', 'Tmod1', 'Slitrk6')
#promote cell proliferation
test3=c('Yap1','Nrg2','Rbn3', 'Mxd3', 'Hydin')
#apoptosis and cellular stress response 
test4=c('Acin1','Bcat1', 'Otud7b', 'Nr4a1', 'Hip1', 'HSPE1', 'HSP90aa1', 'Irf8', 'Traf6')
#cell differentiation and development
test5=c('Creb1', 'YY1', 'Hipk1', 'Bambi', 'Gli2', 'Msi2', 'Sox17', 'Fgf1')
#cell adhersion 
test6=c('Cyfip2','Pcdh7','Cadm2','Lsamp','Tnr','Ncam2','Ncam1','Tmem108')
#test marker
for(gene in test6){
  vioplot_SCINA(brain_exp,gene,paste('~/temp/vioplot_',gene,'.pdf',sep=''))
}
#t tests for Msi2 and Gli2
t1=t.test(brain_exp['Msi2',results$cell_labels=='unknown'],brain_exp['Msi2',results$cell_labels=='OPC'|results$cell_labels=='Oligo'])
t2=t.test(brain_exp['Gli2',results$cell_labels=='unknown'],brain_exp['Gli2',results$cell_labels=='OPC'|results$cell_labels=='Oligo'])