library("cytofkit") 
path='/home2/s421955/projects/singlecellRNA/data/cytof'
cytof_files=list.files(path=path,full.names = T,recursive = FALSE)
for(i in 1:8){
  print(paste('Reading','cytof',str(i),'\n'))
  cytof_days[[i]]=cytof_exprsExtract(fcsFile=cytof_files[i],comp = FALSE,transformMethod = "cytofAsinh")
  names(cytof_days)[i]=tail(strsplit(cytof_files[i],'/')[[1]],1)
}
save(cytof_days,file='/project/bioinformatics/Xiao_lab/shared/singleCell/cytof.RData')