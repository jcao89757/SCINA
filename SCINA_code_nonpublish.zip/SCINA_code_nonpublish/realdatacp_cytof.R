rm(list=ls())
setwd('~/projects/singlecellRNA/data/cellrangerdatasets')
source('~/projects/singlecellRNA/code/EM_model_tw.R')
source('~/projects/singlecellRNA/code/realdatacp_functions.R')
load("~/projects/retrovirus/data/eTME_signatures_v4.RData")
library('biomaRt')
library('preprocessCore')
library('mclust')
library('reshape2')
library("cytofkit")
library('ggplot2')
library('scatterplot3d')
#6.8 Cytof analysis
#data from http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0179385
cytof_days=c()
path='/home2/s421955/projects/singlecellRNA/data/cytof'
cytof_files=list.files(path=path,full.names = T,recursive = FALSE)
for(i in 1:8){
  cytof_days[[i]]=cytof_exprsExtract(fcsFile=cytof_files[i],comp = FALSE,transformMethod = "cytofAsinh")
  names(cytof_days)[i]=tail(strsplit(cytof_files[i],'/')[[1]],1)
}
all_mabs=c()
for(i in 1:length(cytof_days)){all_mabs=c(all_mabs,colnames(cytof_days[[i]]))}
all_mabs=all_mabs[!duplicated(all_mabs)]
signatures_details=list(
  "CD8 T cells"=grep('CD8',all_mabs,value = T),
  'B cells'=grep('B220|CD19',all_mabs,value=T),
  'Monocytes'=grep('F4-80|Ly6C',all_mabs,value=T),
  'Neutrophils'=grep('Ly-6G',all_mabs,value=T),
  'NK cells'=grep('CD49b',all_mabs,value=T)
    )
signatures_immune=list('Immune cells'=grep('CD45',all_mabs,value=T))
results_cells=c()
results_immune=c()
for(i in 1:length(cytof_days)){
  print(i)
  cytof_days[[i]]=t(cytof_days[[i]])
  results_cells[[i]]=try(SCINA(cytof_days[[i]],signatures_details,max_iter=100,convergence_n=10,
                           convergence_rate=0.99,sensitivity_cutoff = 0.33))
  results_immune[[i]]=try(SCINA(cytof_days[[i]],signatures_immune,max_iter=100,convergence_n=10,
                           convergence_rate=0.99,sensitivity_cutoff = 0.33))
}
save(results_cells,results_immune,file='results_cytof.RData')
