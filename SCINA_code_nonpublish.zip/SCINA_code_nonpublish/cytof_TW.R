############  load data  ################

source('/project/SCCC/Wang_lab/shared/tmp/EM_model.R')
# http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0179385
load("/project/bioinformatics/Xiao_lab/shared/singleCell/cytof.RData")

signatures_details=list(
  "CD8 T cells"=c("Tm169Di<TCRb>","Sm152Di<CD3>",grep('CD8',colnames(cytof_days[[1]]),value = T)),
  'CD4 T cells'=c("Tm169Di<TCRb>","Sm152Di<CD3>","Nd145Di<CD4>"),
  'B cells'=c("Sm149Di<CD19>","Yb176Di<B220>"),
  'Monocytes'=c("Nd145Di<CD4>","Nd146Di<F4-80>","Dy162Di<Ly6C>","Nd144Di<CD115>","Sm154Di<CD11b>"),
  'Neutrophils'=c("Pr141Di<Ly-6G>","Sm154Di<CD11b>"),
  'NK cells'=c("Er167Di<NKp46>","Er170Di<CD49b>"),
  'pDC'=c("Ho165Di<CD317>","Yb176Di<B220>"),
  "CD45-"=c("Sm147Di<CD45>") # note CD45 is inverted
)

############  SCINA  ######################

results_cells=c()
for(i in 1:length(cytof_days))
{
  print(i)
  cytof_days_i=t(cytof_days[[i]])
  cytof_days_i["Sm147Di<CD45>",]=-cytof_days_i["Sm147Di<CD45>",] # note CD45 is inverted
  cytof_days_i[]=normalize.quantiles(cytof_days_i)
  
  # sampled 20k cells. The results on all cells should be similar enough
  samples=sample(1:dim(cytof_days_i)[2],20000)
  results_cells[[i]]=SCINA(cytof_days_i[,samples],signatures_details,
    max_iter=100,convergence_n=10,convergence_rate=0.99,sensitivity_cutoff=1,rm_overlap=F)
  results_cells[[i]]$cell_labels[results_cells[[i]]$cell_labels %in% c("unknown","CD45-")]="Other cells"
}

#######  plot  ##########################

cell_types=c(names(signatures_details)[names(signatures_details)!="CD45-"],"Other cells")
detail_plot=matrix(0,nrow=length(cell_types),ncol=length(results_cells))
rownames(detail_plot)=cell_types
for (i in 1:length(results_cells))
{
  tmp=table(results_cells[[i]]$cell_labels)
  detail_plot[names(tmp),i]=tmp/sum(tmp)*100
}

pdf('~/iproject/test/assigned_cell_types.pdf',height=3,width=5.5)
par(xpd=T,mar=c(2,3,2,5))
cols=c("black","red","green3","blue","cyan","magenta","yellow","gray")
barplot(detail_plot,col=cols,border='white',xlab='Days after treatment',xaxt='n',
        ylab='Predicted cells %')
axis(side=1,at=c(1:dim(detail_plot)[2])*1.2-0.5,labels=NA)
text(x=c(1:dim(detail_plot)[2])*1.2-0.5,y=-9,labels=c('Control',1:7),cex = 0.8)
legend(x=10,y=90,legend=rownames(detail_plot),fill=cols,cex=0.7)
dev.off()
