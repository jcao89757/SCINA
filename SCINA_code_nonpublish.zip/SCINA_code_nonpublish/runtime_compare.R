#! 07/11/2018 Ze Zhang This code is to measure the running time differnece between SCINA, cellranger and t-SNE
setwd('~/projects/singlecellRNA/data')
library('cellrangerRkit')
library('biomaRt')
library('mclust')
#1. load data
HEK293_path='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/293T'
jurkat_path='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/jurkat'
gbm_hek293=load_cellranger_matrix(HEK293_path)
gbm_jurkat=load_cellranger_matrix(jurkat_path)
set.seed(0)
hek293cells=colnames(gbm_hek293)
jurkatcells=colnames(gbm_jurkat)
#2. mix cells to generage simulation data. Runnning 10 rounds as steps.
#   recording time, acc and ari as running results.
time_cellranger=c()
acc_cellranger1=c();acc_cellranger2=c()
ari_cellranger=c()
for(i in 1:10){
  #use i*280, at most 2k hek293 cells, i*320, at most 3k jurkat cells
  print(i)
  newhek = gbm_hek293[, sample(hek293cells, size = i*280, replace = FALSE)]
  newjurk = gbm_jurkat[, sample(jurkatcells, size = i*320, replace = FALSE)]
  merge_gbm = list(newhek,newjurk)
  gbm_list <- lapply(merge_gbm, load_molecule_info)
  gbm_list_equalized <- equalize_gbms(gbm_list)
  merged_gbm <- concatenate_gene_bc_matrices(gbm_list_equalized)
  merged_ID <-
    unlist(lapply(1:length(gbm_list), function(x)
      rep(x, dim(gbm_list[[x]])[2])))
  start_time <- Sys.time()
  set.seed(0)
  n_clust <- 2
  pca_result <- run_pca(merged_gbm)
  tsne_result <- run_tsne(pca_result)
  kmeans_result <- run_kmeans_clustering(pca_result, k = n_clust)
  # included re-named cell IDs, t-SNE and k-means result in a merged data frame
  merged_tsne_clust <- data.frame(
    Barcode = as.factor(1:tsne_result$N),
    TSNE.1 = tsne_result$Y[, 1],
    TSNE.2 = tsne_result$Y[, 2],
    Cluster = kmeans_result$cluster,
    Batch = merged_ID
  )
  acc_cellranger1[[i]]=table(merged_tsne_clust$Cluster==merged_ID)['TRUE']/(i*600)
  acc_cellranger2[[i]]=table(merged_tsne_clust$Cluster==merged_ID)['FALSE']/(i*600)
  ari_cellranger[[i]]=adjustedRandIndex(merged_tsne_clust$Cluster,merged_ID)
  end_time <- Sys.time()
  time_cellranger[[i]]=end_time-start_time
}
save(acc_cellranger1,acc_cellranger2,ari_cellranger,time_cellranger,file='cellranger_runtime.RData')
#3. generate plots
load('cellranger_runtime.RData')
load('SCINA_runtime.RData')
load('tsne_runtime.RData')
time_cellranger[4:10]=time_cellranger[4:10]*60
time_tsne[6:10]=time_tsne[6:10]*60
#3.1 lines
pdf('~/temp/runtime.pdf',height=5,width=6)
par(xpd=T,mar=c(5,5,2,5))
x=seq(600,6000,600)
plot(x,time_tsne,type='b',pch=16,lwd=2,col='cyan',xlim=c(0,6600),ylim=c(0,150),xlab='Cell numbers per sample',ylab='Running time (s)',xaxt='n')
lines(x,time_cellranger,type='b',pch=16,lwd=2,col='navy')
lines(x,time_SCINA,type='b',pch=16,lwd=2,col='darkolivegreen1')
axis(side=1,at=seq(600,6000,600),labels = NA)
text(x=seq(600,6000,600),y=-15,srt=45,adj=1,xpd=TRUE,labels=seq(600,6000,600))
legend(x=600,y=140,lwd=2,col=c('cyan','navy','darkolivegreen1'),legend=c('t-SNE','Cell Ranger','SCINA'),cex=0.7)
dev.off()
acc_cellranger=ifelse(is.na(acc_cellranger1),acc_cellranger2,acc_cellranger1)
acc_tsne1[is.na(acc_tsne1)]=0
acc_tsne2[is.na(acc_tsne2)]=0
acc_tsne=ifelse(acc_tsne1>acc_tsne2,acc_tsne1,acc_tsne2)
acc_SCINA[is.na(acc_SCINA)]=1
acc=data.frame(`t-SNE`=acc_tsne,`Cell Ranger`=acc_cellranger,`SCINA`=acc_SCINA,stringsAsFactors = F)
row.names(acc)=seq(600,6000,600)
ari=data.frame(`t-SNE`=ari_tsne,`Cell Ranger`=ari_cellranger,`SCINA`=ari_SCINA,stringsAsFactors = F)
row.names(ari)=seq(600,6000,600)
write.csv(acc,file='~/temp/runtimecp_acc.csv')
write.csv(ari,file='~/temp/runtimecp_ari.csv')
