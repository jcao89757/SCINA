#02/21/2018
#This is a wrap up for EM_simulation.R, extracting its simulation program running and applying parameter sets
#Outputs is a list of acc and aris.
setwd('~/projects/singlecellRNA/code')
source('EM_model_tw.R')
library('MASS')
library('mclust')
#test: Part of normal RNA seqs from retrovirus project
load('/home2/s421955/projects/retrovirus/data/all_mat.RData')
gene_cohort=row.names(all_mat)[1:ctrl_length]
rm(all_mat,samples_allfastq,ctrl_length)
Ilist=c(23442,23442,23442,23442,10000,10000,10000,10000,10000,5000)
Jlist=c(10000,2000,10000,2000,10000,10000,2000,2000,2000,100)
Rlist=c(50,30,50,10,50,10,50,50,10,10)
Sminlist=c(100,5,5,5,100,300,100,5,5,5)
Smaxlist=c(200,50,50,50,200,500,200,50,50,50)
#test:I=Ilist[n];J=Jlist[n];R=Rlist[n];Smin=Sminlist[n];Smax=Smaxlist[n]
#test:I=1000;J=5000;R=2;Smin=10;Smax=20
simpara=function(I,J,R,Smin,Smax,gene_cohort,n){
  print(paste('Paraset:',n))
  signatures=list()
  gene_cohort_tmp=gene_cohort[1:I]
  for(i in 1:R){
    tmp=sample(gene_cohort_tmp,size=runif(1,Smin,Smax));#gene_cohort_tmp=gene_cohort_tmp[!gene_cohort_tmp%in%signatures[[i]]]
    tmp=tmp[!tmp %in% unlist(signatures)] # delete overlap
    signatures[[i]]=tmp
  }
  names(signatures)=paste('sigs',1:length(signatures),sep='_')
  #2. generate theta
  getTheta=function(J,R,signatures){
    theta=list()
    for(i in 1:R){
      theta[[i]]=list()
      theta[[i]]$mean=matrix(0,ncol=2,nrow=length(signatures[[i]]))
      theta[[i]]$cell_prob=runif(1,1,50)#posibility of cells belongs to i type
      for(j in 1:length(signatures[[i]])){
        theta[[i]]$mean[j,1]=runif(1,-6,6)
        theta[[i]]$mean[j,2]=theta[[i]]$mean[j,1]-runif(1,5,15)
        #0309 update: theta unsignature genes' mean should be largely smaller than signature gene means.
      }
      theta[[i]]$sigma1=diag(runif(length(signatures[[i]]),1,10))
      theta[[i]]$sigma2=theta[[i]]$sigma1
    }
    #for(i in 1:3){theta[[i]]$cell_prob=0}
    sum_tao=sum(unlist(sapply(theta,'[',2)))+runif(1,50,150) #+ a random number, give spare space for unidentified model
    for(i in 1:R){theta[[i]]$cell_prob=theta[[i]]$cell_prob/sum_tao}
    return(theta)
  }
  #3. generate target
  getTarget=function(R,J,theta){
    true_label=rep(0,J)
    tmp=unlist(sapply(1:R,function(i) rep(i,round(theta[[i]]$cell_prob*J))))
    true_label[1:length(tmp)]=tmp
    return(true_label)
  }
  #4. generate exp_data
  getExp=function(I,R,J,theta,true_label,signatures){
    exp_data=matrix(runif(I*J,-6,6),nrow=I,ncol=J)
    row.names(exp_data)=gene_cohort[1:I]
    for(i in 1:length(signatures)){
      sqrt_sigma1=sqrt(diag(theta[[i]]$sigma1))
      sqrt_sigma2=sqrt(diag(theta[[i]]$sigma2))
      theta_mean=theta[[i]]$mean
      for (i1 in 1:length(signatures[[i]]))
      {
        exp_data[signatures[[i]][i1],]=
          rnorm(J,theta_mean[i1,ifelse(true_label==i,1,2)],ifelse(true_label==i,sqrt_sigma1,sqrt_sigma2))
        #plot(density(exp_data[signatures[[i]][i1],true_label==i]))
        #lines(density(exp_data[signatures[[i]][i1],true_label!=i]))
        #0309 update at here: simulation data follows different sigma
      }
    }
    return(exp_data)
  }
  theta=getTheta(J,R,signatures)
  true_label=getTarget(R,J,theta)
  exp_data=getExp(I,R,J,theta,true_label,signatures)
  print(paste('Running SCINA for paraset:',n))
  results=SCINA(exp_data,signatures,max_iter=100,convergence_n=10,convergence_rate=0.99,
    sensitivity_cutoff = 0.33)#source('SingleSort.R')
  #only valid when return nums in results as labels
  #matched_result_labels=sapply(names(results$sig),function(name) gsub('sigs_','',name))
  #matched_result_labels=as.numeric(matched_result_labels)
  #results$cell_labels[results$cell_labels!=0]=matched_result_labels[results$cell_labels[results$cell_labels!=0]]
  true_label[true_label!=0]=sapply(true_label[true_label!=0],function(temp) paste('sigs',temp,sep = '_'))
  true_label[true_label==0]='unknown'
  acc=table(results$cell_labels==true_label)[2]/length(true_label)
  ari=adjustedRandIndex(results$cell_labels,true_label)
  if(is.na(acc)){acc=0}
  if(is.na(ari)){ari=0}
  return(list(Acc=acc,ARI=ari,res=results$cell_labels,true=true_label))
}
acc_ari_result=c()
for(n in 1:10){
  acc_ari_result[[n]]=try(simpara(Ilist[n],Jlist[n],Rlist[n],Sminlist[n],Smaxlist[n],gene_cohort,n))
 }
save(acc_ari_result,file='acc_ari_result_0425.RData')