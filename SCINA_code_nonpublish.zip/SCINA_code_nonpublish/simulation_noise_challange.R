#02/21/2018
#This is a second wrap of EM_simulation.R, for adding noise (see summary PPT section 4) to test its robustness
#outputs are heatmaps for wrongly assigned cells
#will apply parameters I=23442,J=500,R=30
setwd('~/projects/singlecellRNA/code')
source('EM_model_tw.R')
library('MASS')
library('mclust')
#test: Part of normal RNA seqs from retrovirus project
load('/home2/s421955/projects/retrovirus/data/all_mat.RData')
gene_cohort=row.names(all_mat)[1:ctrl_length]
rm(all_mat,samples_allfastq,ctrl_length)
round=10;I=23442;J=2000;R=30;Smin=5;Smax=50;plot_status=TRUE
simpara=function(gene_cohort,round,handle,I,J,R,Smin,Smax){
  #round is the times of test
  #handle will decide the type of noise
  #handle=1|2|3,see slides
  #vec=list, vec's length=round
  #I=23442;J=500;R=30;Smin=5;Smax=50
  #test
  batched_results=c()
  batched_results2=c()
  vec=c()
  for(step in 1:(R-1)){
    for(n in 1:round){
      print(paste('Paraset:',n))
      signatures=list()
      gene_cohort_tmp=gene_cohort[1:I]
      for(i in 1:R){
        signatures[[i]]=sample(gene_cohort_tmp,size=runif(1,Smin,Smax))
        gene_cohort_tmp=gene_cohort_tmp[!gene_cohort_tmp%in%signatures[[i]]]
        }
      names(signatures)=paste('sigs',1:length(signatures),sep='_')
      #2. generate theta
      getTheta=function(J,R,signatures){
        theta=list()
        for(i in 1:R){
          theta[[i]]=list()
          theta[[i]]$mean=matrix(0,ncol=2,nrow=length(signatures[[i]]))
          theta[[i]]$cell_prob=runif(1,1,50)#posibility of cells belongs to i type
          for(j in 1:length(signatures[[i]])){
            theta[[i]]$mean[j,1]=runif(1,0,3)
            theta[[i]]$mean[j,2]=runif(1,0,1e-3)
          }
          theta[[i]]$sigma1=diag(runif(length(signatures[[i]]),1e-5,3))
          theta[[i]]$sigma2=theta[[i]]$sigma1
        }
        if(handle==1){vec=sample(1:R,size=step);for(z in vec){theta[[z]]$cell_prob=0}}
        sum_tao=sum(unlist(sapply(theta,'[',2)))+runif(1,5,15) #+ a random number, give spare space for unidentified model
        for(i in 1:R){theta[[i]]$cell_prob=theta[[i]]$cell_prob/sum_tao}
        return(theta)
      }
      #3. generate target
      getTarget=function(R,J,theta){
        true_label=rep(0,J)
        tmp=unlist(sapply(1:R,function(i) rep(i,round(theta[[i]]$cell_prob*J))))
        true_label[1:length(tmp)]=tmp
        return(true_label)
      }
      #4. generate exp_data
      getExp=function(I,R,J,theta,true_label,signatures){
        #exp_data=matrix(runif(I*J,0,0.01),nrow=I,ncol=J)
        exp_data=matrix(0,nrow=I,ncol=J)
        row.names(exp_data)=gene_cohort[1:I]
        for(i in 1:length(signatures)){
          sqrt_sigma1=sqrt(diag(theta[[i]]$sigma1))
          sqrt_sigma2=sqrt(diag(theta[[i]]$sigma2))
          theta_mean=theta[[i]]$mean
          for (i1 in 1:length(signatures[[i]]))
          {
            exp_data[signatures[[i]][i1],]=
              rnorm(J,theta_mean[i1,ifelse(true_label==i,1,2)],ifelse(true_label==i,sqrt_sigma1,sqrt_sigma2))
            #0309 update at here: simulation data follows different sigma
          }
        }
        return(exp_data)
      }
      theta=getTheta(J,R,signatures)
      true_label=getTarget(R,J,theta)
      exp_data=getExp(I,R,J,theta,true_label,signatures)
      if(handle==2){vec=sample(1:R,size=step);signatures=signatures[-vec];true_label[true_label%in%vec]=0}
      if(handle==3){vec=sample(1:R,size=step);for(z in vec){signatures[[z]]=unique(c(signatures[[z]],gene_cohort[round(runif(3,1,I))]))}}
      save(exp_data,signatures,true_label,file='initialexp_sig.RData')
      results=SCINA(exp_data,signatures,max_iter=100,convergence_n=10,convergence_rate=0.99,sensitivity_cutoff = 0.33)#source('SingleSort.R')
      #only valid when return nums in results as labels
      #matched_result_labels=sapply(names(results$sig),function(name) gsub('sigs_','',name))
      #matched_result_labels=as.numeric(matched_result_labels)
      #results$cell_labels[results$cell_labels!=0]=matched_result_labels[results$cell_labels[results$cell_labels!=0]]
      true_label[true_label!=0]=sapply(true_label[true_label!=0],function(temp) paste('sigs',temp,sep = '_'))
      true_label[true_label==0]='unknown'
      acc=table(results$cell_labels==true_label)[2]/length(true_label)
      ari=adjustedRandIndex(results$cell_labels,true_label)
      if(is.na(acc)){acc=0}
      if(is.na(ari)){ari=0}
      batched_results[[n]]=list(true_label=true_label,results_label=results$cell_labels,acc=acc,ari=ari)
    }
    batched_results2=c(batched_results2,batched_results)
  }
  return(batched_results2)
}

results1=simpara(gene_cohort,round,handle = 1,I,J,R,Smin,Smax)
results2=simpara(gene_cohort,round,handle = 2,I,J,R,Smin,Smax)
results3=simpara(gene_cohort,round,handle = 3,I,J,R,Smin,Smax)
save(results1,results2,results3,file = 'noisechallangeresults_0430.RData')
#load('noisechallangeresults_0430.RData')

plot_acc_ari=function(file,main,results,round,R){
  plot_error=function(x, y, sd, len = 1, col = "black") {
    len=len * 0.05
    arrows(x0 = x, y0 = y, x1 = x, y1 = y - sd, col = col, angle = 90, length = len)
    arrows(x0 = x, y0 = y, x1 = x, y1 = y + sd, col = col, angle = 90, length = len)
  }
  acc_mat=matrix(as.numeric(sapply(results,'[',3)),ncol=round,byrow=TRUE)
  ari_mat=matrix(as.numeric(sapply(results,'[',4)),ncol=round,byrow=TRUE)
  acc_mean=sapply(1:(R-1),function(i) mean(acc_mat[i,]))
  ari_mean=sapply(1:(R-1),function(i) mean(ari_mat[i,]))
  acc_sd=sapply(1:(R-1),function(i) sd(acc_mat[i,]))
  ari_sd=sapply(1:(R-1),function(i) sd(ari_mat[i,]))
  pdf(file,width=5,height=3)
  plot(x=1:(R-1),y=acc_mean,type='l',lty=1,lwd=2,col='red',xaxt='n',xlim=c(0,R),ylim=c(0.5,1.5),xlab='Ratio of signatures with noise',ylab=,main=main)
  plot_error(x=1:(R-1),y=acc_mean,sd=acc_sd,col='red')
  lines(x=1:(R-1),y=ari_mean,type='l',lty=1,lwd=2,col='blue')
  plot_error(x=1:(R-1),y=ari_mean,sd=ari_sd,col='blue')
  legend('topright',legend=c('Accuracy','ARI'),col=c('red','blue'),lty=1,lwd=2,bty='n',cex=0.7)
  labels=seq(1,(R-1),3)/R;axis(side=1,at=seq(1,(R-1),3),labels=round(labels,2),cex=0.5,srt=45)
  dev.off()
}
if(plot_status==TRUE){
  plot_acc_ari(file='~/temp/acc_ari_noise1.pdf',main='Add unused signatures',results=results1,round,R)
  plot_acc_ari(file='~/temp/acc_ari_noise2.pdf',main='Lack true signatures',results=results2,round,R)
  plot_acc_ari(file='~/temp/acc_ari_noise3.pdf',main='Noise genes in signatures',results=results3,round,R)
}

