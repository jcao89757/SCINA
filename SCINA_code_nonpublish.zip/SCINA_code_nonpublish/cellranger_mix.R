#This script is for the in silico mixture of cellranger datasets
#source("http://cf.10xgenomics.com/supp/cell-exp/rkit-install-2.0.0.R")
setwd('~/projects/singlecellRNA/data/')
library('cellrangerRkit')
library('biomaRt')
library('mclust')
HEK293_path='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/293T'
jurkat_path='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/jurkat'
gbm_hek293=load_cellranger_matrix(HEK293_path)
gbm_jurkat=load_cellranger_matrix(jurkat_path)
set.seed(0)
hek293cells=colnames(gbm_hek293)
jurkatcells=colnames(gbm_jurkat)
total=2000
acc1=list()
acc2=list()
ari=list()
trueID=c()
predictID=c()
for(i in 1:99) {
  len = c(total * i / 100, total * (100 - i) / 100)
  print(len)
  set.seed(len[1])
  newhek = gbm_hek293[, sample(hek293cells, size = len[1], replace = FALSE)]
  newjurk = gbm_jurkat[, sample(jurkatcells, size = len[2], replace = FALSE)]
  merge_gbm = list(newhek,newjurk)
  gbm_list <- lapply(merge_gbm, load_molecule_info)
  gbm_list_equalized <- equalize_gbms(gbm_list)
  merged_gbm <- concatenate_gene_bc_matrices(gbm_list_equalized)
  merged_ID <-
    unlist(lapply(1:length(gbm_list), function(x)
      rep(x, dim(gbm_list[[x]])[2])))
  #save_cellranger_matrix_h5(merged_gbm, paste('/home2/s421955/projects/singlecellRNA/data/mix_293T_new/',i,'per_merge.h5',sep=''), 'hg19')
  #save_cellranger_matrix_h5(newjurk, paste('/home2/s421955/projects/singlecellRNA/data/mix_293T_new/',i,'per_jerk.h5',sep=''), 'hg19')
  set.seed(0)
  n_clust =2:3
  pca_result <- run_pca(merged_gbm)
  tsne_result <- run_tsne(pca_result)
  kmeans_result=list()
  for(j in 1:2){tmp=run_kmeans_clustering(pca_result, k = n_clust[j]);kmeans_result[[j]]=tmp$cluster}
  # included re-named cell IDs, t-SNE and k-means result in a merged data frame
  merged_tsne_clust <- data.frame(
    Barcode = as.factor(1:tsne_result$N),
    TSNE.1 = tsne_result$Y[, 1],
    TSNE.2 = tsne_result$Y[, 2],
    Batch = merged_ID
  )
  trueID[[i]]=merged_ID
  predictID[[i]]=kmeans_result
  acc1_tmp=list()
  acc2_tmp=list()
  ari_tmp=list()
  for(j in 1:2){acc1_tmp[[j]]=table(kmeans_result[[j]]==merged_ID)['TRUE']/total}
  for(j in 1:2){acc2_tmp[[j]]=table(kmeans_result[[j]]==merged_ID)['FALSE']/total}
  for(j in 1:2){ari_tmp[[j]]=adjustedRandIndex(kmeans_result[[j]],merged_ID)}
  acc1[[i]]=acc1_tmp
  acc2[[i]]=acc2_tmp
  ari[[i]]=ari_tmp
  ###########Seurat: graph model
  #obj=CreateSeuratObject(merged_gbm)
  #FindClusters()
}
save(acc1,acc2,ari,trueID,predictID,file='~/projects/singlecellRNA/data/mix293T_jurk_result_cellranger_2clusters.RData')
