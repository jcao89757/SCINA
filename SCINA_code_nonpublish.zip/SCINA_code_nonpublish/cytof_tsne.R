library('preprocessCore')
library('Rtsne')
source('/project/SCCC/Wang_lab/shared/tmp/EM_model.R')
# http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0179385
load("/project/bioinformatics/Xiao_lab/shared/singleCell/cytof.RData")
signatures_details=list(
  "CD8 T cells"=c("Tm169Di<TCRb>","Sm152Di<CD3>",grep('CD8',colnames(cytof_days[[1]]),value = T),"Sm147Di<CD45>"),
  'CD4 T cells'=c("Tm169Di<TCRb>","Sm152Di<CD3>","Nd145Di<CD4>","Sm147Di<CD45>"),
  'B cells'=c("Sm149Di<CD19>","Yb176Di<B220>","Sm147Di<CD45>"),
  'Monocytes'=c("Nd145Di<CD4>","Nd146Di<F4-80>","Dy162Di<Ly6C>","Nd144Di<CD115>","Sm154Di<CD11b>","Sm147Di<CD45>"),
  'Neutrophils'=c("Pr141Di<Ly-6G>","Sm154Di<CD11b>","Sm147Di<CD45>"),
  'NK cells'=c("Er167Di<NKp46>","Er170Di<CD49b>","Sm147Di<CD45>"),
  'pDC'=c("Ho165Di<CD317>","Yb176Di<B220>","Sm147Di<CD45>")
)
allfeature=unique(unlist(signatures_details))
for(i in 1:length(cytof_days))
{
  print(i)
  cytof_days[[i]]=log(t(cytof_days[[i]])+1)
  cytof_days[[i]][]=normalize.quantiles(cytof_days[[i]])
}
tsne_result=c()
set.seed(2345)
for(i in 1:length(cytof_days)){
  print(paste('tSNE',str(i),'\n'))
  tmp=t(cytof_days[[i]])
  ind=sample(row.names(tmp),size=28000)
  tsne_result[[i]]=Rtsne(tmp[ind,colnames(tmp)%in%allfeature],dims=2,theta=1,verbose=T)
  tsne_result[[i]]$ind=ind
}
save(tsne_result,file='~/projects/singlecellRNA/data/cytof_tsne_test2.RData')
load('~/projects/singlecellRNA/data/cytof_tsne_test2.RData')
load('~/projects/singlecellRNA/data/cytof_SCINA_test5.RData')
col=c(rainbow(7),'grey')
pdf('~/temp/tsne20kcytof_test2.pdf',height=4,width=4)
par(xpd = T, mar = par()$mar + c(0,0,0,3))
for(i in 1:length(tsne_result)){
  label=results_cells[[i]]$cell_labels[match(tsne_result[[i]]$ind,row.names(cytof_days[[i]]))]
  collab=col[as.numeric(factor(label,levels=c(names(signatures_details),'unknown')))]
  plot(tsne_result[[i]]$Y[,1],tsne_result[[i]]$Y[,2],pch=19,col=collab,
       xlab="t-SNE1",ylab="t-SNE2",cex=0.1,main=i)
  legend(x=max(tsne_result[[i]]$Y[,1])+4,y=20,legend=c(names(signatures_details),'unknown'),
          fill=c(rainbow(7),'grey'),cex=0.7)
}
dev.off()
