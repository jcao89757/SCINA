#! usr/bin/env python
import h5py
import numpy as np
from scipy.sparse import csc_matrix
#test at here
name='testfile_500cells.h5'
#exp=np.random.randint(low=1,high=400,size=(33694,10))
#exp=np.ones(shape=(33694,10),dtype=int)
#exp[0:10000,0:3]=exp[0:10000,0:3]+300
#exp[10000:20000,3:6]=exp[10000:20000,3:6]+300
#exp[20000:30000,6:10]=exp[20000:30000,6:10]+300

exp=np.loadtxt('/home2/s421955/temp/500cellsmoc.csv',dtype='str',delimiter=',')
exp=exp[1:,].astype(np.int)
#main functions
def BuildH5F(exp,name):
    barcode = '~/projects/singlecellRNA/data/egbarcode.txt'
    genenames = '~/projects/singlecellRNA/data/eggenenames.txt'
    genes = '~/projects/singlecellRNA/data/eggenes.txt'
    #barcode='/home2/s421955/projects/singlecellRNA/data/egbarcode.csv'
    #genenames='/home2/s421955/projects/singlecellRNA/data/eggenenames.csv'
    #genes='/home2/s421955/projects/singlecellRNA/data/eggenes.csv'
    bar=np.loadtxt(barcode,dtype='str',delimiter=',')
    genenames=np.loadtxt(genenames,dtype='str',delimiter=',')
    genes=np.loadtxt(genes,dtype='str',delimiter=',')
    f=h5py.File(name,'w')
    fgroup=f.create_group('CRinput_sim1')
    bar_inh5=fgroup.create_dataset('barcodes',data=bar)
    gene_inh5=fgroup.create_dataset('genes',data=genes)
    genenames_inh5=fgroup.create_dataset('gene_names',data=genenames)
    exp_inh5=csc_matrix(exp)
    data_inh5=fgroup.create_dataset('data',data=exp_inh5.data,dtype=int)
    indices_inh5=fgroup.create_dataset('indices',data=exp_inh5.indices)
    indptr_inh5=fgroup.create_dataset('indptr',data=exp_inh5.indptr)
    shape_inh5=fgroup.create_dataset('shape',data=exp_inh5.shape)
    f.close()

BuildH5F(exp=exp,name=name)
