#This script is used to run SNN clustering on 293T_jurkat cellranger dataset mixture
rm(list=ls())
setwd('/home2/s421955/projects/singlecellRNA/code')
source('~/projects/singlecellRNA/code/realdatacp_functions.R')
source('/project/bioinformatics/Xiao_lab/s421955/projects/singlecellRNA/code/SNN.R')
#1. set up python interface
library(reticulate)
use_python("/cm/shared/apps/python/2.7.x-anaconda/bin/python")
py_available(initialize = T)
#2. mix and run SNN
load('batched_jurkat_293T.RData')
jurkat_293T=batched_mat
rm(batched_mat)
total=2000
pca_dim=50
for(i in 1:99){
  vec=c(1,2)
  len=c(total*i/100,total*(100-i)/100)
  print(len)
  exp_test=mixexp(vec,len,jurkat_293T)
  pca=prcomp(exp_test$exp_data)
  pca=pca$rotation
  outfile= paste('/home2/s421955/temp/SNN_outs/',i,'_hek.txt',sep='')
  SNN(pca[,1:pca_dim],outfile,k=3,distance="euclidean")
  #3. catch SNN output and run python module 
  python_out=paste('/home2/s421955/temp/SNN_outs/',i,'_hekout.txt',sep='')
  file.create(python_out)
  source_python('/home2/s421955/projects/singlecellRNA/code/Cliq.py')
  main(list('-i',outfile,'-o',python_out))
}