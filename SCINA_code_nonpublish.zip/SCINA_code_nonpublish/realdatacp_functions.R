#04222018 Ze Zhang
#This script stores functions for realdatacp.R, to simplify scripts.
setwd('~/projects/singlecellRNA/data/cellrangerdatasets')
library('biomaRt')
library('preprocessCore')
library('mclust')
#0. read csvs as batched_mat
read_convert_datasets = function(path, file_name) {
  mart = useDataset("hsapiens_gene_ensembl", useMart("ensembl"))
  matdir = list.files(path=path,full.names = T,recursive = FALSE)
  matdir = matdir[grepl('csv$', matdir)]
  n = 0
  batched_mat = c()
  for (name in matdir) {
    n = n + 1
    mat = read.csv(name, stringsAsFactors = F)
    gene = mat[, 1]
    gene_list = getBM(
      filters = "ensembl_gene_id",
      attributes = c("ensembl_gene_id", "hgnc_symbol"),
      values = gene,
      mart = mart
    )
    mat = merge(mat, gene_list, by.x = "X", by.y = "ensembl_gene_id")
    mat = mat[!grepl("^$", mat[, "hgnc_symbol"]), ]
    mat = aggregate(mat[, 2:(dim(mat)[2] - 1)], by = list(mat[, "hgnc_symbol"]), sum)
    row.names(mat) = mat[, "Group.1"]
    mat = as.matrix(mat[, 2:dim(mat)[2]])
    batched_mat[[n]] = mat
    names(batched_mat)[n] = gsub('.csv', '', name)
  }
  save(batched_mat, file = file_name)
}
#0.1 jim's internal kidney data
exp_data=read.table("~/projects/singlecellRNA/data/jim_kidney_scRNA/RCC_02092018.txt",
                    header=T,stringsAsFactors = F)
meta=read.table("~/projects/singlecellRNA/data/jim_kidney_scRNA/RCC_02092018_metadata.txt",
                header=T,stringsAsFactors = F)
all(rownames(meta)==colnames(exp_data)[-c(1,2)])

exp_data=exp_data[!duplicated(exp_data$SYMBOL),]
genes=exp_data$SYMBOL
exp_data=as.matrix(exp_data[,-c(1:2)])
rownames(exp_data)=genes
library(preprocessCore)
exp_data[]=normalize.quantiles(exp_data)

meta$sample[meta$sample=="Tumor-Lymphoid"]="Lymphoid"
meta$sample[meta$sample=="Tumor-Myeoid"]="Myeloid"
meta$sample[meta$sample %in% c("Tumor-NL-II","Tumor-RBC-L-I")]="Lymphoid"
meta$sample[meta$sample %in% c("Tumor-NL-I","Tumor-RBC-L-II")]="Myeloid"
meta$sample[meta$sample %in% c("Tumor-RBC-L","Tumor-RBC-NL")]="Lymphoid"

table(meta$pool,meta$sample)
table(meta$sample)
jim_scRNA=c()
jim_scRNA[[1]]=exp_data[,colnames(exp_data)%in%row.names(meta)[meta$sample=="Lymphoid"]]
jim_scRNA[[2]]=exp_data[,colnames(exp_data)%in%row.names(meta)[meta$sample=="Myeloid"]]
names(jim_scRNA)=c("Lymphoid","Myeloid")
save(jim_scRNA,file='jim_scRNA.RData')
#1.Randomaly select cells from batched_mat
mixexp=function(vec,len,batched_mat){
  #vec is a vector contains types of cells to stratify, nums
  #len is a vector contains amount of samples to stratify,nums
  exp_data=c()
  true_label=c()
  for(i in 1:length(vec)){
    exp_ind=sample(1:dim(batched_mat[[vec[i]]])[2],size = len[i],replace = FALSE)
    exp_data=cbind(exp_data,batched_mat[[vec[i]]][,exp_ind])
    true_label=c(true_label,rep(names(batched_mat)[vec[i]],len[i]))
  } 
  exp_data=log(exp_data+1)
  exp_data[]=normalize.quantiles(exp_data)
  #normalization after combined exp_data sets
  return(list(exp_data=exp_data,true_label=true_label))
}
#2.Main fucntion
SCINA_truedata=function(vec,len,batched_mat,signatures,file){
  exp_test=mixexp(vec,len,batched_mat)
  exp_pcaplot(vec,len,exp_test)
  #test:signatures=signatures_4bmat;exp=exp_test$exp_data;max_iter=100;convergence_n=10;convergence_rate=0.99;sensitivity_cutoff = 0.33
  results=SCINA(exp_test$exp_data,signatures,max_iter=100,convergence_n=10,
                convergence_rate=0.99,sensitivity_cutoff = 0.33)
  acc=table(results$cell_labels==exp_test$true_label)['TRUE']/length(exp_test$true_label)
  ari=adjustedRandIndex(results$cell_labels,exp_test$true_label)
  save(exp_test,results,acc,ari,file = file)
}
#3.pca plot to sort PCA clusterable cells
exp_pcaplot=function(vec,len,exp_test){
  pca=prcomp(exp_test$exp_data)
  pca=pca$rotation
  col_vec=c()
  colfull=c('cadetblue1','coral','aquamarine2','blueviolet','darkgray','darkgoldenrod1','darkolivegreen','black','deeppink')
  for(i in 1:length(vec)){
    tmp1=rep(colfull[vec[i]],len[i])
    col_vec=c(col_vec,tmp1)
  }
  pdf('~/temp/testpca.pdf')
  scatterplot3d(x=pca[,1],y=pca[,2],z=pca[,3],color=col_vec)
  dev.off()
}
#########5.Signature genes expression levels in real data, archived test
# batched_mat=batched_mat[-c(7,8)]
# signatures_4bmat=signatures_4bmat[-c(7,8)]
# testwithin=matrix(ncol=7,nrow=7)
# testothers=matrix(ncol=7,nrow=7)
# for(i in 1:7){
#   for(j in 1:7){
#     mat=batched_mat[[i]]
#     sigtest=signatures_4bmat[[j]]
#     gentest=sigtest[sigtest%in%row.names(mat)]
#     mean_siggene=mean(mat[gentest,])
#     mean_nonsig=mean(mat[setdiff(row.names(mat),gentest),])
#     testwithin[i,j]=mean_siggene
#     testothers[i,j]=mean_nonsig
#   }
# }
# row.names(testwithin)=row.names(testothers)=names(batched_mat)
# colnames(testwithin)=colnames(testothers)=names(signatures_4bmat)
#6. Find most highly expressed genes in one exp_data mat
#batched_mat: part of the batched_mat that we use to define singatures
#batched_mat should be raw counts
#cells: all cell types we want to divide
#n:cell numbers of each cell type to decide cell signatures
#cutoff:exp(cutoff) is the fold change of signaturegenes maxexp/meanexp
findgenesigs=function(batched_mat,cells,n,cutoff){
  mean_cell=c()
  for (cell in cells){
    tmp=log(batched_mat[[cell]][,1:n]+1)
    mean_cell=cbind(mean_cell,rowMeans(tmp,na.rm = T))
    }
  signatures=list()
  for(i in 1:dim(mean_cell)[1]){
    cell_max=which.max(mean_cell[i,])# fold change of 2 (exp(0.7)=2)
    if (mean_cell[i,cell_max,drop=F]>max(mean_cell[i,-cell_max,drop=F])+cutoff) {
      signatures[[cells[cell_max]]]=c(signatures[[cells[cell_max]]],rownames(mean_cell)[i])
    }
  }
  return(signatures)
}

