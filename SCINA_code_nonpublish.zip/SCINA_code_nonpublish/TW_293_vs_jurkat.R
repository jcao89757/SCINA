########  load data  #############

load("~/projects/singlecellRNA/data/cellrangerdatasets/batched_jurkat_293T.RData")

# Hek293 
# https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM2693929
# GSM2693929_HEK293_siGFP_control.count_RPKM.txt

# Jurkat 
# https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE69511
# GSE69511_CBAPs-FPKM_values_data.txt

hek293=read.table("/project/SCCC/Wang_lab/shared/tmp/293_vs_jurkat/GSM2693929_HEK293_siGFP_control.count_RPKM.txt",stringsAsFactors = F,header=T, sep="\t")
jurkat=read.table("/project/SCCC/Wang_lab/shared/tmp/293_vs_jurkat/GSE69511_CBAPs-FPKM_values_data.txt",stringsAsFactors = F,header=T, sep="\t")
hek293=hek293[hek293$GeneName %in% jurkat$Name,]
rownames(jurkat)=jurkat$Name
jurkat=jurkat[hek293$GeneName,]

#######  define signatures  #########

define_sig=data.frame(gene=hek293$GeneName,
  hek293=hek293$RPKM,jurkat=apply(jurkat[,grepl("CBAP",colnames(jurkat))],1,mean),
  stringsAsFactors = F)
define_sig$hek293=define_sig$hek293/mean(define_sig$hek293)
define_sig$jurkat=define_sig$jurkat/mean(define_sig$jurkat)
define_sig=define_sig[define_sig$gene %in% rownames(batched_mat[[1]]),]

signatures_Jk_293T=list("293T"=define_sig$gene[(define_sig$hek293+1)/(define_sig$jurkat+1)>20],
  "jurkat"=define_sig$gene[(define_sig$jurkat+1)/(define_sig$hek293+1)>20])
save(signatures_Jk_293T,file='~/projects/singlecellRNA/data/sigs_jk_293T.RData')
##########  SCINA  ################
####  testing mixing ratios from 1% - 99%  ############

source("~/projects/singlecellRNA/code/EM_model_tw.R")
max_iter=100
convergence_n=20
convergence_rate=0.99
sensitivity_cutoff=1

n1=1980 # number of cells to analyze
n2=20 
exp_data=log(cbind(batched_mat[[1]][,1:n1],batched_mat[[2]][,1:n2])+1)
results=SCINA(exp_data,signatures,max_iter,convergence_n,convergence_rate,sensitivity_cutoff)
table(results$cell_labels,c(rep("HEK293",n1),rep("Jurkat",n2)))

n1=1000 # number of cells to analyze
n2=1000 
exp_data=log(cbind(batched_mat[[1]][,1:n1],batched_mat[[2]][,1:n2])+1)
results=SCINA(exp_data,signatures,max_iter,convergence_n,convergence_rate,sensitivity_cutoff)
table(results$cell_labels,c(rep("HEK293",n1),rep("Jurkat",n2)))

n1=20 # number of cells to analyze
n2=1980 
exp_data=log(cbind(batched_mat[[1]][,1:n1],batched_mat[[2]][,1:n2])+1)
results=SCINA(exp_data,signatures,max_iter,convergence_n,convergence_rate,sensitivity_cutoff)
table(results$cell_labels,c(rep("HEK293",n1),rep("Jurkat",n2)))
