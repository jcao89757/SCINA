#############  load data  ##############

library('gdata')
library('preprocessCore')
source('/home2/s421955/projects/singlecellRNA/code/SCENA/R/EM_model.R')
source('/home2/s421955/projects/singlecellRNA/code/SCENA/R/EM_functions.R')
load('/home2/s421955/projects/singlecellRNA/data/cytof_crispr/stk4/stk4.RData')
stk4_ind=read.xls('~/iproject/Stk4.wsp_flowjo.xls')

#######  preprocess FACS data  #############

for(i in 1:length(cytof_mice))
{
  cytof_mice[[i]]=cytof_mice[[i]][cytof_mice[[i]][,"FSC-A<NA>"]>0.5,] # filter out debris
  resid=cytof_mice[[i]][,"FSC-A<NA>"]- # keep only singlet
    predict(lm(cytof_mice[[i]][,"FSC-A<NA>"]~cytof_mice[[i]][,"FSC-H<NA>"]))
  cytof_mice[[i]]=cytof_mice[[i]][abs(resid)<0.5,]
}

########  define signatures  ##################

# https://www.bdbiosciences.com/documents/cd_marker_handbook.pdf
# https://www.bio-rad-antibodies.com/mouse-immune-cell-markers-selection-tool.html#marker=cd11b
signatures1=list(
  'T cells'=c("FITC-A<CD3>"),
  "B cells"=c("450/50 (325)-A<CD19>","low_BV711-A<CD11c>"),
  'NK(T) cells'=c("BV650-A<NK1-1>"),
  'DC cells'=c("low_PE-CF594-A<CD44>","low_PE-Cy7-A<CD62L>","BV605-A<CD11b>"),
  'Macrophages/Neutrophils'=c("SSC-A<NA>","BV605-A<CD11b>")
)

signatures2=list("CD8 T cells"=c("BV510-A<CD8>"),"CD4 T cells"=c("BV785-A<CD4>"))

sorted=matrix(0,nrow=length(cytof_mice),ncol=7)
colnames(sorted)=c("B cells","NK(T) cells","DC cells","Macrophages/Neutrophils","CD8 T cells",
                   "CD4 T cells","unknown")
rownames(sorted)=names(cytof_mice)

#########  SCENA  ################

for(i in 1:length(cytof_mice))
{
  # first round SCENA
  scena1=SCENA(t(cytof_mice[[i]]),signatures1,100,10,0.99,1,FALSE)

  # second round SCENA
  keep=scena1$cell_labels=="T cells"
  if (any(keep))
  {
    scena2=SCENA(t(cytof_mice[[i]][keep,]),signatures2,100,10,0.99,1,FALSE)
    scena1$cell_labels[keep]=scena2$cell_labels
  }

  # report
  tmp=table(scena1$cell_labels)/length(scena1$cell_labels)
  print(tmp)
  sorted[i,names(tmp)]=tmp
}
save(sorted,file='~/projects/singlecellRNA/data/result_facs_crispr_TW.RData')
#########  correlate with genetics data  ###################

