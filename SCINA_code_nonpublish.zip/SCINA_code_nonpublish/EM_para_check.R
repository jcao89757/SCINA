EM_check=function(exp,signatures,max_iter,convergence_n,convergence_rate,sensitivity_cutoff,rm_overlap)
{
  # initialize parameters
  quality=TRUE
  def_max_iter=1000
  def_conv_n=10
  def_conv_rate=0.99
  def_dummycut=0.33 
  allgenes=row.names(exp)
  
  # clean exp
  if (any(is.na(exp))) 
  {
    print('NA exists in expression matrix.')
    quality=FALSE
  }
  
  # clean signatures
  if (any(is.na(signatures)))
  {
    print('Null cell type signature genes.');quality=FALSE
  }else
  {
    #na.omit(NAs) in each signatures,remove unvalid genes (not in exp)
    signatures=sapply(signatures,function(x) unique(x[(!is.na(x)) & (x %in% allgenes)]),simplify=F)
    
    #remove duplicate genes
    if(rm_overlap)
    {
      tmp=table(unlist(signatures))
      signatures=sapply(signatures,function(x) x[x %in% names(tmp[tmp==1])],simplify=F)
    }
    #check if any genes have all 0 counts
    signatures=sapply(signatures,function(x) x[apply(exp[x,,drop=F],1,sd)>0],simplify=F)
  }
  # clean other parameters
  if (is.na(convergence_n))
  {
    print('Using convergence_n=default')
    convergence_n=def_conv_n
  }
  if (is.na(max_iter))
  {
    print('Using max_iter=default')
    max_iter=def_max_iter
  }else
  {
    if (max_iter<convergence_n)
    {
      print('Using max_iter=default due to smaller than convergence_n.')
      max_iter=def_max_iter # this theorectically, still doesn't ensure max_iter>convergence_n (Tao)
    }
  }
  
  if (is.na(convergence_rate))
  {
    print('Using convergence_rate=default.')
    convergence_rate=def_conv_rate
  }
  
  if (is.na(sensitivity_cutoff))
  {
    print('Using sensitivity_cutoff=default.')
    sensitivity_cutoff=def_dummycut
  }
  # return cleaned data
  return(list(qual=quality,sig=signatures,
    para=c(max_iter,convergence_n,convergence_rate,sensitivity_cutoff)))
}
