#Jan19, 2018
#build test dataset for EM
setwd('~/projects/singlecellRNA')
source('EM_model.R')
library('MASS')
load('/home2/s421955/projects/retrovirus/data/all_mat.RData')
load('/home2/s421955/projects/retrovirus/data/eIST_signatures.v2.RData')
signatures=signatures[c(1:6)]
output='testEMresults.Rdata'
genes_select=unlist(sapply(signatures,'[',c(1,2)))
genes_select=c(genes_select[1,],genes_select[2,])
exp=na.omit(all_mat[genes_select,1:10])
rm(all_mat,ctrl_length,samples_allfastq)
convergence_n=10;convergence_rate=0.99;max_iter=100
results=EMtrain(exp,signatures,max_iter,convergence_n,convergence_rate)
save(results,file=output)
