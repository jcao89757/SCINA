########  load data  #########

load("/project/SCCC/Wang_lab/shared/cellranger_scRNA/batched_filtered_expmat.RData")
source("~/iproject/test/EM_model_tw.R")
n=500 # number of cells in each type

########  define signature genes with one part of the data  ##############

cells=c("b_cells","cd14_monocytes","cd4_t_helper","cd56_nk","cytotoxic_t",
        "memory_t","naive_t","regulatory_t") # cell types to choose from, at first
mean_cell=c()
for (cell in cells) # mean expression in each cell
  {mean_cell=cbind(mean_cell,apply(log(batched_mat[[cell]][,-c(1:n)]+1),1,mean))}

signatures=list() # define signatures
for (i in 1:dim(mean_cell)[1])
{
  cell_max=which.max(mean_cell[i,])
  if (mean_cell[i,cell_max]>max(mean_cell[i,-cell_max])+0.7) # fold change of 2 (exp(0.7)=2)
    {signatures[[cells[cell_max]]]=c(signatures[[cells[cell_max]]],rownames(mean_cell)[i])}
}
cells=names(signatures) # only these cell types have signature genes defined
all_genes=unlist(signatures)

##############  SCINA on the other part of the data  ###############

exp_data=c()
for (cell in c(cells,"naive_t")) # the last one is used as the "unknown" cell type
{
  exp_data=cbind(exp_data,batched_mat[[cell]][rownames(batched_mat[[cell]]) %in% all_genes,1:n])
}

# SCINA analysis
results=SCINA(log(exp_data+1),signatures,
  max_iter=100,convergence_n=10,convergence_rate=0.999,sensitivity_cutoff = 0.33)

# accuracy
table(results$cell_labels,rep(c(cells,"unknown"),each=n))
sum(results$cell_labels==rep(c(cells,"unknown"),each=n))/dim(exp_data)[2]

