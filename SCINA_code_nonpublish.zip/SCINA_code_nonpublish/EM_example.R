#Jan19,2018
#Interface for EM model, input parameters at here,receive results out
source('/home2/s421955/projects/singlecellRNA/code/SCINA/R/EM_functions.R')
source('/home2/s421955/projects/singlecellRNA/code/SCINA/R/EM_model.R')
setwd('/home2/s421955/projects/singlecellRNA/code/SCINA')
load('./example/example_expmat.RData')
load('./example/example_signatures.RData')
exp=exp_test$exp_data
results=SCINA(exp,signatures,max_iter=120,convergence_n=12,convergence_rate=0.999,sensitivity_cutoff=0.9)
table(exp_test$true_label,results$cell_labels)
