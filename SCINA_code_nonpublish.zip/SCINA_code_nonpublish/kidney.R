library('reshape2')
############  read data  ##############
exp_data=read.table("/home2/s421955/projects/singlecellRNA/data/jim_kidney_scRNA/RCC_02092018.txt",
                    header=T,stringsAsFactors = F)
meta=read.table("/home2/s421955/projects/singlecellRNA/data/jim_kidney_scRNA/RCC_02092018_metadata.txt",
                header=T,stringsAsFactors = F)
all(rownames(meta)==colnames(exp_data)[-c(1,2)])

exp_data=exp_data[!duplicated(exp_data$SYMBOL),]
genes=exp_data$SYMBOL
exp_data=as.matrix(exp_data[,-c(1:2)])
rownames(exp_data)=genes
library(preprocessCore)
exp_data[]=normalize.quantiles(exp_data)

meta$sample_cb[meta$sample=="Tumor-Lymphoid"]="Lymphoid"
meta$sample_cb[meta$sample=="Tumor-Myeoid"]="Myeloid"
meta$sample_cb[meta$sample %in% c("Tumor-NL-II","Tumor-RBC-L-I")]="Lymphoid"
meta$sample_cb[meta$sample %in% c("Tumor-NL-I","Tumor-RBC-L-II")]="Myeloid"
meta$sample_cb[meta$sample %in% c("Tumor-RBC-L","Tumor-RBC-NL")]="Lymphoid"
meta$sample_cb[is.na(meta$sample_cb)]=meta$sample[is.na(meta$sample_cb)]
table(meta$pool,meta$sample)
table(meta$sample)
table(meta$sample_cb)
###########  predict cell type for each immune cell  ############

# get signatures, combine some of them
load("~/projects/retrovirus/data/eTME_signatures.RData")

# divide into lymphoid and myeloid lineages
lymphoid=c("B cells","CD8 T cells","Treg cells","Th1 cells","Th2 cells","Tfh cells","Tm cells",
           "CD56dim NK cells","CD56bright NK cells")
myeloid=c("Macrophages","Neutrophils","Mast cells")
both=c("Dendritic cells")

# SCINA
source('~/projects/singlecellRNA/code/SCINA/R/EM_model.R')
source('~/projects/singlecellRNA/code/SCINA/R/EM_functions.R')
results=SCINA(log(exp_data+0.2),signatures[c(lymphoid,myeloid,both)],
  max_iter=100,convergence_n=10,convergence_rate=0.999,sensitivity_cutoff = 0.99,rm_overlap = T)

# accuracy
table(results$cell_labels,meta$sample_cb) 
meta$result_labelsmore=results$cell_labels
meta$result_labelsless=results$cell_labels
meta$result_labelsless[meta$result_labelsless%in%lymphoid]='Lymphoid'
meta$result_labelsless[meta$result_labelsless%in%myeloid]='Myeloid'
# how many of the cells can be assigned
sum(results$cell_labels!="unknown")/length(results$cell_labels)
save(meta,file="~/temp/results_kidney.RData")

# classified correctly as L or M
(sum(grepl("Lymphoid",meta$sample_cb) & results$cell_labels %in% lymphoid)+
  sum(grepl("Myeloid",meta$sample_cb) & results$cell_labels %in% myeloid))/
  sum(!results$cell_labels %in% c(both,"unknown"))
#Hypergeometric p value
hypertest=phyper(q=sum(grepl("Myeloid",meta$sample_cb)),
                 m=sum(results$cell_labels %in% myeloid),
       n=sum(grepl("Lymphoid",meta$sample_cb)),
       k=sum(!results$cell_labels %in% c(both,"unknown")),
       lower.tail = FALSE, log.p = FALSE
             )
pdf('~/temp/Fig3A_jimkidney.pdf',height=4,width=3)
stack2plot=table(meta$sample_cb,meta$result_labelsless)
stack2plot_percent=apply(stack2plot,2,function(x){x*100/sum(x,na.rm=T)})
par(xpd = T, mar = par()$mar + c(0,0,0,3))
barplot(stack2plot_percent,col=c('deepskyblue','goldenrod1'),border='white',xlab='True labels',xaxt='n',ylab='Predicted labels %')
axis(side=1,at=c(1:dim(stack2plot_percent)[2])*1.2-0.5,labels=NA)
text(x=c(1:dim(stack2plot_percent)[2])*1.2-0.5,y=-7,srt=45,adj=1,xpd=TRUE,labels=colnames(stack2plot_percent),cex = 0.8)
legend(x=5,y=90,legend=c('Lymphoid','Myeloid'),fill=c('deepskyblue','goldenrod1'),cex=0.8)
#par(mar=c(5, 4, 4, 2) + 0.1)
dev.off()

# Ze, I took the liberty of changing some of your codes in this script 
# to improve the results of Eosinophils
# But I didn't change the part below, which will cause some minor problem 
# with the placement of the dashed gray bars
pdf('~/temp/Fig3B_jimkidney.pdf',height=6,width=6)
stack2plot=table(meta$sample_cb,meta$result_labelsmore)
stack2plot=stack2plot[,c(lymphoid[lymphoid!='Tfh cells'],myeloid,both,'unknown')]
stack2plot_percent=apply(stack2plot,2,function(x){x*100/sum(x,na.rm=T)})
par(xpd = T, mar = par()$mar + c(3,0,3,3))
barplot(stack2plot_percent,col=c('deepskyblue','goldenrod1'),border='white',xlab=NA,xaxt='n',ylab='Predicted labels %')
axis(side=1,at=c(1:dim(stack2plot_percent)[2])*1.2-0.3,labels=NA)
text(x=c(1:dim(stack2plot_percent)[2])*1.2-0.3,y=-7,srt=45,adj=1,xpd=TRUE,labels=colnames(stack2plot_percent),cex = 0.8)
text(x=dim(stack2plot_percent)[2]/2,y=-42,labels='True labels')
segments(x0=9.7,y0=0,x1=9.7,y1=120,col='grey60',lty=2,lwd=2)
text(x=4,y=110,labels='Lymphoid',col='grey60',cex=0.8)
segments(x0=14.5,y0=0,x1=14.5,y1=120,col='grey60',lty=2,lwd=2)
text(x=12,y=110,labels='Myeloid',col='grey60',cex=0.8)
text(x=15.7,y=110,labels='Others',col='grey60',cex=0.8)
legend(x=17,y=90,legend=c('Lymphoid','Myeloid'),fill=c('deepskyblue','goldenrod1'),cex=0.8)
par(mar=c(5, 4, 4, 2) + 0.1)
dev.off()
####mock cellranger
library('MASS')
library('mclust')
pca=prcomp(exp_data)
pca=pca$rotation
km=kmeans(pca[,1:10],center=2)#10 degrees of PCA is preferred by cell ranger
ari_cr=adjustedRandIndex(km$cluster,as.factor(meta$sample_cb))
