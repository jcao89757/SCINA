#############  load data  ##############

library('gdata')
library(mclust)

source('/project/SCCC/Wang_lab/shared/tmp/SCINA/EM_model.R') # change this to the SCINA R package
source('/project/SCCC/Wang_lab/shared/tmp/SCINA/EM_functions.R') # change this to the SCINA R package

load('~/iproject/stk4.RData') 
manual_results=read.csv('/project/SCCC/Wang_lab/shared/tmp/Stk4_manual.csv',stringsAsFactors = F)

#######  preprocess FACS data  #############

for(i in 1:length(cytof_mice))
{
  cytof_mice[[i]]=cytof_mice[[i]][cytof_mice[[i]][,"FSC-A<NA>"]>0.5,] # filter out debris
  resid=cytof_mice[[i]][,"FSC-A<NA>"]- # keep only singlet
    predict(lm(cytof_mice[[i]][,"FSC-A<NA>"]~cytof_mice[[i]][,"FSC-H<NA>"]))
  cytof_mice[[i]]=cytof_mice[[i]][abs(resid)<0.5,]
  
  cytof_mice[[i]]=cytof_mice[[i]][sample(1:dim(cytof_mice[[i]])[1],2000),]
}

########  define signatures  ##################

# https://www.bdbiosciences.com/documents/cd_marker_handbook.pdf
# https://www.bio-rad-antibodies.com/mouse-immune-cell-markers-selection-tool.html#marker=cd11b
# https://www.google.com/search?q=fsc-a&source=lnms&tbm=isch&sa=X&ved=0ahUKEwjyjvDvuP_bAhVDWK0KHSVbA54Q_AUIDSgE&biw=1536&bih=760#imgrc=InlgNjQsBitxSM:
signatures1=list( 
  'T cells'=c("FITC-A<CD3>","low_BV605-A<CD11b>"),
  "B cells"=c("450/50 (325)-A<CD19>","low_BV605-A<CD11b>"),
  'NK(T) cells'=c("BV650-A<NK1-1>"),
  'DC cells'=c("low_PE-CF594-A<CD44>","low_APC-A<CD43>"), 
  'Macrophages/Neutrophils'=c("SSC-A<NA>","FSC-A<NA>")
)

signatures2=list("CD8 T cells"=c("BV510-A<CD8>"),"CD4 T cells"=c("BV785-A<CD4>"))
# in mice, macrophages have characteristically low CD4 expression
signatures3=list("Macrophages"=c("PE-A<F4/80>"),"Neutrophils"=c("BV785-A<CD4>")) 

#########  SCINA  ################

sorted=matrix(0,nrow=length(cytof_mice),ncol=10)
colnames(sorted)=c("B1 cells","B2 cells","NK cells","NKT cells","DC cells","Macrophages","Neutrophils",
                   "CD8 T cells","CD4 T cells","unknown")

for(i in 1:length(cytof_mice))
{
  # first round SCINA
  SCINA1=SCINA(t(cytof_mice[[i]]),signatures1,100,10,0.99,1,FALSE,FALSE)
  
  # separate CD4 and CD8 T cells
  keep=SCINA1$cell_labels=="T cells"
  if (any(keep))
  {    
    SCINA2=SCINA(t(cytof_mice[[i]][keep,]),signatures2,100,10,0.99,1,FALSE,FALSE)
    SCINA1$cell_labels[keep]=SCINA2$cell_labels
  }
  
  # separate B1 and B2 cells
  keep=SCINA1$cell_labels=="B cells"
  if (any(keep))
  {    
    cd45r=cytof_mice[[i]][keep,"Alexa Fluor 700-A<CD45R>"]
    cutoff=median(cd45r)-mad(cd45r)*5
    SCINA1$cell_labels[keep]=ifelse(cd45r>cutoff,"B2 cells","B1 cells")
  }
  
  # separate NK and NKT cells
  keep=SCINA1$cell_labels=="NK(T) cells"
  if (any(keep))
  {    
    SCINA1$cell_labels[keep]=
      ifelse(cytof_mice[[i]][keep,"FITC-A<CD3>"]>4,"NKT cells","NK cells")
  }
  
  # separate macrophages and neutrophils
  keep=SCINA1$cell_labels=="Macrophages/Neutrophils"
  if (any(keep))
  {    
    SCINA3=SCINA(t(cytof_mice[[i]][keep,]),signatures3,100,10,0.99,1,FALSE,FALSE)
    SCINA1$cell_labels[keep]=SCINA3$cell_labels
  }
  
  # report 
  tmp=table(SCINA1$cell_labels)/length(SCINA1$cell_labels)
  print(tmp)
  sorted[i,names(tmp)]=tmp
}

#########  correlate with genetics data  ###############

# pay attention here!
# the data that Xue uploaded are not complete!
manual_results=manual_results[1:32,]
sorted=as.data.frame(sorted)
rownames(sorted)=manual_results$ear_tag

genotype=read.csv("/project/SCCC/Wang_lab/shared/tmp/crispr_mice_genotypes.csv",stringsAsFactors = F)
genotype=genotype[genotype$symbol=="Stk4" & genotype$ear_tag %in% rownames(sorted),]
mutations=factor(genotype$genotype,levels=c("WT","HET","HOM"))

sorted=sorted[genotype$ear_tag,]
rownames(manual_results)=manual_results$ear_tag
manual_results=manual_results[genotype$ear_tag,]

par(mfrow=c(1,2))

plot(sorted$`CD4 T cells`~mutations,xlab="CRISPR Genotype",ylab="CD4 T cells:SCINA")
plot(manual_results$facs_cd4_t_cells~mutations,xlab="CRISPR Genotype",ylab="CD4 T cells:manual")

plot(sorted$`CD8 T cells`~mutations,xlab="CRISPR Genotype",ylab="CD8 T cells:SCINA")
plot(manual_results$facs_cd8_t_cells~mutations,xlab="CRISPR Genotype",ylab="CD8 T cells:manual")

plot(sorted$Neutrophils~mutations,xlab="CRISPR Genotype",ylab="Neutrophils:SCINA")
plot(manual_results$facs_neutrophils~mutations,xlab="CRISPR Genotype",ylab="Neutrophils:manual")

