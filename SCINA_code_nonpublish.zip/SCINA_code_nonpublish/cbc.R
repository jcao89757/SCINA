# read data 
setwd('/home2/s421955/projects/singlecellRNA/data')
a=read.csv("Stk4_CRISPR_CBC.csv",stringsAsFactors = F)
a=a[a$Measurement=="Test No",]
rownames(a)=a$X
for (i in 3:dim(a)[2]) {a[,i]=as.numeric(a[,i])}

b=read.csv("crispr_mice_genotypes.csv",stringsAsFactors = F)
b=b[b$symbol=="Stk4" & b$ear_tag %in% a$X,]
a=a[b$ear_tag,]

# plot neutrophils
# we are actually sorting neutrophils, eos, baso, and mast together as granulocytes
# but neu is the largest population of granulocytes
plot((a$NE.+a$EO.+a$BA.)~factor(b$genotype,levels=c("WT","HET","HOM")))
plot((a$WBC-a$LY.-a$MO.)~factor(b$genotype,levels=c("WT","HET","HOM")))
#lymphocytes
pdf('~/temp/lymphocytes_cdc.pdf',height=3,width=2)
plot((a$LY.)~factor(b$genotype,levels=c("WT","HET","HOM")),xlab='CBC results',ylab='Lymphocyte counts',col=c('deepskyblue','darkseagreen1','gold'))
dev.off()
#Neutrophils
pdf('~/temp/neutrophils_cdc.pdf',height=3,width=2)
plot((a$NE.)~factor(b$genotype,levels=c("WT","HET","HOM")),xlab='CBC results',ylab='Neutrophil counts',col=c('deepskyblue','darkseagreen1','gold'))
pval=anova(lm(a$NE.~factor(b$genotype,levels=c("WT","HET","HOM"))))$'Pr(>F)'[1]
dev.off()
# macrophages
pdf('~/temp/macrophages_cdc.pdf',height=3,width=2)
plot((a$MO.)~factor(b$genotype,levels=c("WT","HET","HOM")),xlab='CBC results',ylab='Macrophage counts',col=c('deepskyblue','darkseagreen1','gold'))
pval=anova(lm(a$MO.~factor(b$genotype,levels=c("WT","HET","HOM"))))$'Pr(>F)'[1]
dev.off()

