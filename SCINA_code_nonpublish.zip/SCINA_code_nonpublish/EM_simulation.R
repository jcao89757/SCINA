#Jan 26th 2018
#This script is for em model simulation
#Inheret gene names and gene signatures from exp_data and signatures from Em_test
setwd('~/projects/singlecellRNA/code/SCINA/R')
source('EM_model.R')
source('EM_functions.R')
library('MASS')
library('gplots')
library('RColorBrewer')
library('reticulate')
library('lattice')
library('reshape')
library('mclust')
#test: Part of normal RNA seqs from retrovirus project
load('/home2/s421955/projects/retrovirus/data/all_mat.RData')
gene_cohort=row.names(all_mat)[1:ctrl_length]
rm(all_mat,samples_allfastq,ctrl_length)
I=23442 #too small will cause most cells unidentified.
#I=23000#number of genes
J=2000#number of cells
R=30#numberof cell types
handle=0#represtnes not carry any testing
#1. generate R lists as signatures of genes
signatures=list()
gene_cohort_tmp=gene_cohort[1:I]
for(i in 1:R){signatures[[i]]=sample(gene_cohort_tmp,size=runif(1,5,50));gene_cohort_tmp=gene_cohort_tmp[!gene_cohort_tmp%in%signatures[[i]]]}
names(signatures)=paste('sigs',1:length(signatures),sep='_')
#2. generate theta
getTheta=function(J,R,signatures){
  theta=list()
  for(i in 1:R){
    theta[[i]]=list()
    theta[[i]]$mean=matrix(0,ncol=2,nrow=length(signatures[[i]]))
    theta[[i]]$cell_prob=runif(1,1,50)#posibility of cells belongs to i type
    for(j in 1:length(signatures[[i]])){
      theta[[i]]$mean[j,1]=runif(1,0,3)
      theta[[i]]$mean[j,2]=runif(1,0,1e-3)
    }
    theta[[i]]$sigma1=diag(runif(length(signatures[[i]]),1e-5,3))
    theta[[i]]$sigma2=theta[[i]]$sigma1
  }
  if(handle==1){vec=sample(1:R,size=step);for(z in vec){theta[[z]]$cell_prob=0}}
  sum_tao=sum(unlist(sapply(theta,'[',2)))+runif(1,5,15) #+ a random number, give spare space for unidentified model
  for(i in 1:R){theta[[i]]$cell_prob=theta[[i]]$cell_prob/sum_tao}
  return(theta)
}
#3. generate target
getTarget=function(R,J,theta){
  true_label=rep(0,J)
  tmp=unlist(sapply(1:R,function(i) rep(i,round(theta[[i]]$cell_prob*J))))
  true_label[1:length(tmp)]=tmp
  return(true_label)
}
#4. generate exp_data
getExp=function(I,R,J,theta,true_label,signatures){
  #exp_data=matrix(runif(I*J,0,0.01),nrow=I,ncol=J)
  exp_data=matrix(0,nrow=I,ncol=J)
  row.names(exp_data)=gene_cohort[1:I]
  for(i in 1:length(signatures)){
    sqrt_sigma1=sqrt(diag(theta[[i]]$sigma1))
    sqrt_sigma2=sqrt(diag(theta[[i]]$sigma2))
    theta_mean=theta[[i]]$mean
    for (i1 in 1:length(signatures[[i]]))
    {
      exp_data[signatures[[i]][i1],]=
        rnorm(J,theta_mean[i1,ifelse(true_label==i,1,2)],ifelse(true_label==i,sqrt_sigma1,sqrt_sigma2))
      #0309 update at here: simulation data follows different sigma
    }
  }
  return(exp_data)
}
set.seed(123)
theta=getTheta(J,R,signatures)
true_label=getTarget(R,J,theta)
exp_data=getExp(I,R,J,theta,true_label,signatures)
results=SCINA(exp_data,signatures,max_iter=100,convergence_n=10,convergence_rate=0.999,sensitivity_cutoff = 0.33)#source('SingleSort.R')
#only valid when return nums in results as labels
#matched_result_labels=sapply(names(results$sig),function(name) gsub('sigs_','',name))
#matched_result_labels=as.numeric(matched_result_labels)
#results$cell_labels[results$cell_labels!=0]=matched_result_labels[results$cell_labels[results$cell_labels!=0]]
true_label[true_label!=0]=sapply(true_label[true_label!=0],function(temp) paste('sigs',temp,sep = '_'))
true_label[true_label==0]='unknown'
#source('SingleSort_EM.R')
#results=SingleSort(exp_data,signatures,Convergence_n=10,Convergence_rate=0.99,Max_iterate=1000,
                   #tao=NULL)
#1. heatmap visualize predicted and true labels
intersect_heatmap=function(R,results,true_label,signatures,file,width,height){
  data2table=data.frame(predict=results$cell_labels,target=true_label,stringsAsFactors = F)
  #num2labels=c('unidentified',names(signatures))
  #data2table$target=sapply(data2table$target,function(name) paste('sigs',name,sep='_'))
  #ind=data2table$target=='sigs_0'
  #data2table$target[ind]='unidentified'
  #data2table$predict=factor(num2labels[data2table$predict+1],levels=c(paste("sigs",1:30,sep="_"),"unidentified"))
  #data2table$target=factor(num2labels[data2table$target+1],levels=c(paste("sigs",1:30,sep="_"),"unidentified"))
  data2table$predict=factor(data2table$predict,levels=c(paste("sigs",1:R,sep="_"),"unknown"))
  data2table$target=factor(data2table$target,levels=c(paste("sigs",1:R,sep="_"),"unknown"))
  pdf(file=file,width=width,height=height)
  heatmap.2(table(data2table),trace='none',cellnote=table(data2table),notecol='black',col=c('azure2',brewer.pal(7,'YlOrRd')),
    breaks=c(0,0.1,1,3,5,7,10,15,30),density.info='none',notecex=0.6,
    dendrogram='none',Rowv=FALSE,Colv=FALSE,xlab='True labels',ylab='Predicted labels',
    cexRow = 0.8,labRow = c(paste("Cell type",1:30,sep=" "),"Unknown"),cexCol = 0.8,labCol = c(paste("Cell type",1:30,sep=" "),"Unknown"),margins = c(6.5,6.5))
  dev.off()
}
intersect_heatmap(R,results,true_label,results$sig,file='~/temp/simulparaheat500cells_0515.pdf',width=8,height=8)
acc=table(results$cell_labels==true_label)[2]/length(true_label)
ari=adjustedRandIndex(results$cell_labels,true_label)
#1.5 (temp 041718) pca cluster plot for 5 clusters of cells
tag_true_label=unique(true_label)[1:5]
predict_label=results$cell_labels[true_label%in%tag_true_label]
exp_data_2pca=exp_data[,true_label%in%tag_true_label]
true_label=true_label[true_label%in%tag_true_label]
col=c('blue','red','green','darkgoldenrod1','black')
pch=c('1','2','3','4','5')
col_truelabel=c()
pch_predictlabel=c()
for(i in 1:length(tag_true_label)){
  tmp=rep(col[i],table(true_label)[i])
  col_truelabel=c(col_truelabel,tmp)
  tmp=rep(pch[i],table(predict_label)[i])
  pch_predictlabel=c(pch_predictlabel,tmp)
  }
pca=prcomp(exp_data_2pca)
pca=as.matrix(pca$rotation[,1:3])
pdf('~/temp/testpca.pdf')
scatterplot3d(x=pca[,1],y=pca[,2],z=pca[,3],color=col_truelabel,pch=pch_predictlabel)
dev.off()
#2. Comparesion: cellrange prediction
exp_after=matrix(1,nrow=(33694-dim(exp_data)[1]),ncol=J)
exp=rbind(exp_data,exp_after)
exp_unlog=round(exp(exp))
sig_genes=unlist(signatures)
map_genes=read.csv('../data/eggenes.txt',header=F,stringsAsFactors = F)
include_genes=map_genes[match(sig_genes,gene_cohort),]
names(include_genes)='Gene'
write.csv(exp_unlog,file='~/temp/500cells02.csv',row.names = FALSE)
write.table(include_genes,file='~/temp/includegeneID02.csv',col.names='Gene',sep='\t',row.names = F,quote = F)
graph_result=read.csv('/home2/s421955/projects/singlecellRNA/code/500celltest/outs/analysis/clustering/graphclust/clusters.csv',stringsAsFactors = F)
