#This script is used to apply cellranger r toolkit for cellranger datasets
#'B cells','Monocytes','Natural killer cells','Unknown'("regulatory_t")
#Reanalysi with r toolkit
#sample 100 cells in each datasets
#Preprocess downloaded Gene/cell matrix (filtered) from the website: for example, b_cells
# (1) mkdir outs; mv * ./outs
# (2) mv ./outs/filtered_matrices_mex/ ./outs/filtered_gene_bc_matrices_mex/
# (3) wget Summary CSV from the website and save it in ./outs
# (4) mv ./outs/b_cells_metrics_summary.csv ./outs/metrics_summary.csv
# (5) wget Per-molecule read infromation and save it as ./outs/raw_molecule_info.h5
setwd('~/projects/singlecellRNA/data/')
library('cellrangerRkit')
library('biomaRt')
library('mclust')
path=list();gbm=list()
path[[1]]='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/b_cells'
path[[2]]='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/cd14_monocytes'
path[[3]]='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/cd56_nk'
path[[4]]='/home2/s421955/projects/singlecellRNA/data/cellrangerdatasets/regulatory_t'
for(i in 1:length(path)){gbm[[i]]=load_cellranger_matrix(path[[i]])}
cells=list()
for(i in 1:length(path)){cells[[i]]=colnames(gbm[[i]])}
len=100
set.seed(0)
new_gbm_1=gbm[[1]][, sample(cells[[1]], size = len, replace = FALSE)]
new_gbm_2=gbm[[2]][, sample(cells[[2]], size = len, replace = FALSE)]
new_gbm_3=gbm[[3]][, sample(cells[[3]], size = len, replace = FALSE)]
new_gbm_4=gbm[[4]][, sample(cells[[4]], size = len, replace = FALSE)]
merge_gbm =list(new_gbm_1,new_gbm_2,new_gbm_3,new_gbm_4)
gbm_list <- lapply(merge_gbm, load_molecule_info)
gbm_list_equalized <- equalize_gbms(gbm_list)
merged_gbm <- concatenate_gene_bc_matrices(gbm_list_equalized)
merged_ID <-
  unlist(lapply(1:length(gbm_list), function(x)
    rep(x, dim(gbm_list[[x]])[2])))
set.seed(0)
n_clust =4
pca_result <- run_pca(merged_gbm)
tsne_result <- run_tsne(pca_result)
kmeans_result=run_kmeans_clustering(pca_result, k = n_clust)
table(kmeans_result$cluster)
acc1=table(kmeans_result$cluster==merged_ID)['TRUE']/(len*length(path))
acc2=table(kmeans_result$cluster==merged_ID)['FALSE']/(len*length(path))
ari=adjustedRandIndex(kmeans_result$cluster,merged_ID)
