setwd('~/projects/singlecellRNA/data')
# read data
library('Rtsne')
library('preprocessCore')
library('mclust')
#1. prepare data and signatures
load("/project/SCCC/Wang_lab/shared/cellranger_scRNA/batched_jurkat_293T.RData")
hek293=read.table("/project/SCCC/Wang_lab/shared/tmp/293_vs_jurkat/GSM2693929_HEK293_siGFP_control.count_RPKM.txt",stringsAsFactors = F,header=T, sep="\t")
jurkat=read.table("/project/SCCC/Wang_lab/shared/tmp/293_vs_jurkat/GSE69511_CBAPs-FPKM_values_data.txt",stringsAsFactors = F,header=T, sep="\t")
hek293=hek293[hek293$GeneName %in% jurkat$Name,]
rownames(jurkat)=jurkat$Name
jurkat=jurkat[hek293$GeneName,]
#2. t-SNE
acc_tsne1=c();acc_tsne2=c()
ari_tsne=c()
time_tsne=c()
for(i in 1:10){
  #use i*280, at most 2k hek293 cells, i*320, at most 3k jurkat cells
  print(i)
  exp_data=log(cbind(batched_mat[[1]][,sample(1:dim(batched_mat[[1]])[2], size = i*280, replace = FALSE)],
                     batched_mat[[2]][,sample(1:dim(batched_mat[[2]])[2], size = i*320, replace = FALSE)])+1)
  exp_data[]=normalize.quantiles(exp_data)
  tmp=t(exp_data)
  start_time=Sys.time()
  results=Rtsne(tmp,dims=2,theta=1,verbose=T)
  end_time=Sys.time()
  kmeans_result <- kmeans(results$Y,centers = 2)
  true_label=c(rep(1,i*280),rep(2,i*320))
  acc_tsne1[[i]]=table(kmeans_result$cluster==true_label)['TRUE']/dim(exp_data)[2]
  acc_tsne2[[i]]=table(kmeans_result$cluster==true_label)['FALSE']/dim(exp_data)[2]
  ari_tsne[[i]]=adjustedRandIndex(kmeans_result$cluster,true_label)
  time_tsne[[i]]=end_time-start_time
}
save(acc_tsne1,acc_tsne2,ari_tsne,time_tsne,file='tsne_runtime.RData')
