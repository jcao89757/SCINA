setwd('/home2/s421955/projects/singlecellRNA/data/cytof_crispr/')
library("cytofkit")
library('preprocessCore')
source('/home2/s421955/projects/singlecellRNA/code/SCINA/R/EM_model.R')
source('/home2/s421955/projects/singlecellRNA/code/SCINA/R/EM_functions.R')
#0. load data
load_facs=function(path){
  print(path)
  cytof_files=list.files(path=path,full.names = T,pattern='\\.fcs$',recursive = FALSE)
  ind_file=list.files(path=path,full.names = T,pattern='\\.xls$',recursive = FALSE)
  cytof_mice=c()
  for(i in 1:length(cytof_files)){
    print(paste('Reading','cytof',i))
    cytof_mice[[i]]=cytof_exprsExtract(fcsFile=cytof_files[i],comp = FALSE,transformMethod = "cytofAsinh")

    names(cytof_mice)[i]=tail(strsplit(cytof_files[i],'/')[[1]],1)
  }
  ind=read.xls(ind_file)
  if(dim(ind)[1]!=length(cytof_mice)){
    print('Warning: index of this experiment does not match.')
    if(dim(ind)[1]>length(cytof_mice)){ind=ind[1:length(cytof_mice),]}
    if(dim(ind)[1]<length(cytof_mice)){cytof_mice=cytof_mice[1:dim(ind)[1]]}
    }
  return(list(facs=cytof_mice,ind=ind))
}
#1. preprocess facs data
preprocessFacs=function(cytof_data){
  for(i in 1:length(cytof_data$facs)){
    print(i)
    resid = cytof_data$facs[[i]][, "FSC-A<NA>"] -
      predict(lm(cytof_data$facs[[i]][, "FSC-A<NA>"] ~ cytof_data$facs[[i]][, "FSC-H<NA>"]))
    cytof_data$facs[[i]] = cytof_data$facs[[i]][abs(resid) < 0.5, ]
    cytof_data$facs[[i]]=cytof_data$facs[[i]][cytof_data$facs[[i]][,"FSC-A<NA>"]>0.5,] # filter out debris
    cytof_data$facs[[i]] = t(cytof_data$facs[[i]])}
  return(cytof_data)
}
#2. SCINA wrapper

crisprSCINA=function(cytof_data,ind,signatures1,signatures2,signatures3){
  sorted=matrix(0,nrow=length(cytof_data),ncol=10)
  colnames(sorted)=c("B1 cells","B2 cells","NK cells","NKT cells",'mDC cells',"Macrophages","Neutrophils",
                     "CD8 T cells","CD4 T cells","unknown")
  markers=c()
  for(i in 1:length(cytof_data)){
    print(paste('Ongoing',i))
    scena1=SCINA(cytof_data[[i]],signatures1,100,10,0.99,1,FALSE)
    keep=scena1$cell_labels=="T cells"
    if (any(keep))
    {
      scena2=try(SCINA(cytof_data[[i]][,keep],signatures2,100,10,0.99,1,FALSE))
      scena1$cell_labels[keep]=scena2$cell_labels
    }
    keep=scena1$cell_labels=="B cells"
    if (any(keep))
    {
      cd45r=cytof_data[[i]]["Alexa Fluor 700-A<CD45R>",keep]
      cutoff=median(cd45r)-mad(cd45r)*5
      scena1$cell_labels[keep]=ifelse(cd45r>cutoff,"B2 cells","B1 cells")
    }
    keep=scena1$cell_labels=="NK cells"
    if (any(keep))
    {
      cd3=cytof_data[[i]]["FITC-A<CD3>",keep]
      cutoff=median(cd3)-mad(cd3)*5
      scena1$cell_labels[keep]=ifelse(cd3>cutoff,"NKT cells","NK cells")
    }
    keep=scena1$cell_labels=="Macrophages/Neutrophils"
    if (any(keep))
    {
      scena3=try(SCINA(cytof_data[[i]][,keep],signatures3,100,10,0.99,1,FALSE))
      #scena3$cell_labels[scena3$cell_labels=='unknown']='Macrophages'
      #scena3$cell_labels[scena3$cell_labels=='Other lymphocytes']='unknown'
      scena1$cell_labels[keep]=scena3$cell_labels
    }
    if(!any(is.na(scena1))){
      markers[[i]]=scena1
    }else{print(i);stop('ERROR on SCINA:')}
    tmp=table(scena1$cell_labels)/length(scena1$cell_labels)
    print(tmp)
    sorted[i,names(tmp)]=tmp
  }
  row.names(sorted)=ind$ear_tag
  return(list(scena1full=markers,sorted=sorted))
}
#3. correlation test
test_correlation=function(sorted,ind){
  b.test=cor.test(apply(sorted[,c('B1 cells','B2 cells')],1,sum),ind$facs_b_cells)
  t.test=cor.test(apply(sorted[,c('CD4 T cells','CD8 T cells')],1,sum),ind$facs_t_cells)
  NK.test=cor.test(sorted[,'NK cells'],ind$facs_nk_cells)
  NKT.test=cor.test(sorted[,'NKT cells'],ind$facs_nk_cells)
  neutrophils.test=cor.test(sorted[,'Neutrophils'],ind$facs_neutrophils)
  macrophages.test=cor.test(sorted[,'Macrophages'],ind$facs_macrophages)
  mDC.test=cor.test(sorted[,'mDC cells'],ind$facs_cd11c_dcs)
  result=data.frame(Cells=c('B cells','T cells','NK cells','NKT cells','Neutrophils','Macrophages','mDC cells'),
                    Cor=c(b.test$estimate,t.test$estimate,NK.test$estimate,NKT.test$estimate,neutrophils.test$estimate,
                          macrophages.test$estimate,mDC.test$estimate),stringsAsFactors = F)
  return(result)
}
#4. match genotypes
genoplot=function(name,results,cytof_data,manual_results,pic1,pic2){
  genotype=read.csv("/project/SCCC/Wang_lab/shared/tmp/crispr_mice_genotypes.csv",stringsAsFactors = F)
  genotype=genotype[genotype$symbol==name & genotype$ear_tag %in% row.names(results$sorted),]
  mutations=factor(genotype$genotype,levels=c("WT","HET","HOM"))
  results$sorted=data.frame(results$sorted[genotype$ear_tag,],stringsAsFactors = F)
  rownames(manual_results)=manual_results$ear_tag
  manual_results=manual_results[genotype$ear_tag,]
  pdf(pic1,width=7,height=3)
  par(mfrow=c(1,2))
  test=anova(lm(results$sorted[,"B1.cells"]~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,"B1.cells"]~mutations,xlab="CRISPR Genotype",ylab="B1 cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_b1_cells~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_b1_cells~mutations,xlab="CRISPR Genotype",ylab="B1 cells:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,"B2.cells"]~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,"B2.cells"]~mutations,xlab="CRISPR Genotype",ylab="B2 cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_b2_cells~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_b2_cells~mutations,xlab="CRISPR Genotype",ylab="B2 cells:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,"CD4.T.cells"]~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,"CD4.T.cells"]~mutations,xlab="CRISPR Genotype",ylab="CD4 T cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_cd4_t_cells~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_cd4_t_cells~mutations,xlab="CRISPR Genotype",ylab="CD4 T cells:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,"CD8.T.cells"]~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,"CD8.T.cells"]~mutations,xlab="CRISPR Genotype",ylab="CD8 T cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_cd8_t_cells~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_cd8_t_cells~mutations,xlab="CRISPR Genotype",ylab="CD8 T cells:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted$Neutrophils~mutations))$'Pr(>F)'[1]
  plot(results$sorted$Neutrophils~mutations,xlab="CRISPR Genotype",ylab="Neutrophils:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_neutrophils~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_neutrophils~mutations,xlab="CRISPR Genotype",ylab="Neutrophils:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,'Macrophages']~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,'Macrophages']~mutations,xlab="CRISPR Genotype",ylab="Macrophages:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_macrophages~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_macrophages~mutations,xlab="CRISPR Genotype",ylab="Macrophages:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,'NK.cells']~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,'NK.cells']~mutations,xlab="CRISPR Genotype",ylab="NK cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_nk_cells~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_nk_cells~mutations,xlab="CRISPR Genotype",ylab="NK cells:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,'NKT.cells']~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,'NKT.cells']~mutations,xlab="CRISPR Genotype",ylab="NKT cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_nk_t_cells~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_nk_t_cells~mutations,xlab="CRISPR Genotype",ylab="NKT cells:manual",main=paste('P-val',round(test,4)))

  test=anova(lm(results$sorted[,'mDC.cells']~mutations))$'Pr(>F)'[1]
  plot(results$sorted[,'mDC.cells']~mutations,xlab="CRISPR Genotype",ylab="mDC cells:SCINA",main=paste('P-val',round(test,4)))
  test=anova(lm(manual_results$facs_cd11c_dcs~mutations))$'Pr(>F)'[1]
  plot(manual_results$facs_cd11c_dcs~mutations,xlab="CRISPR Genotype",ylab="mDC cells:manual",main=paste('P-val',round(test,4)))
  dev.off()
  pdf(pic2,width=10,height=5)
  par(mfrow=c(1,2))
  for(i in 3:4){
    #4.1 B cells desnsity plot
    tmp=data.frame(facs=cytof_data[[i]]['450/50 (325)-A<CD19>',],labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    plot(density(tmp$facs[tmp$labels!='B1 cells'&tmp$labels!='B2 cells']),xlab='450/50 (325)-A<CD19>',ylim=c(0,1),ylab='Frequency',col='blue',lwd=2,main=paste('B cells:','mice',i,name))
    lines(density(tmp$facs[tmp$labels=='B1 cells'|tmp$labels=='B2 cells']),col='red',lwd=2)
    legend('topright',legend = c('B cells','Non-B cells'),col=c('red','blue'),lwd=2)
    #4.2 T cells desnsity plot
    tmp=data.frame(facs=cytof_data[[i]]['FITC-A<CD3>',],labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    plot(density(tmp$facs[grepl('T cells',tmp$labels)]),xlab='FITC-A<CD3>',ylim=c(0,1),ylab='Frequency',col='red',lwd=2,main=paste('T cells:','mice',i,name))
    lines(density(tmp$facs[!grepl('T cells',tmp$labels)]),col='blue',lwd=2)
    legend('topright',legend = c('T cells','Non-T cells'),col=c('red','blue'),lwd=2)
    #4.3 NK cells desnsity plot
    tmp=data.frame(facs=cytof_data[[i]]['BV650-A<NK1-1>',],labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    plot(density(tmp$facs[grepl('NK',tmp$labels)]),xlab='BV650-A<NK1-1>',ylim=c(0,1),ylab='Frequency',col='red',lwd=2,main=paste('NK(T) cells:','mice',i,name))
    lines(density(tmp$facs[!grepl('NK',tmp$labels)]),col='blue',lwd=2)
    legend('topright',legend = c('NK(T) cells','Non-NK(T) cells'),col=c('red','blue'),lwd=2)
    #4.3 mDC cells desnsity plot
    tmp=data.frame(facs=cytof_data[[i]]['BV711-A<CD11c>',],labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    plot(density(tmp$facs[grepl('mDC',tmp$labels)]),xlab='BV711-A<CD11c>',ylim=c(0,1),ylab='Frequency',col='red',lwd=2,main=paste('mDC cells:','mice',i,name))
    lines(density(tmp$facs[!grepl('mDC',tmp$labels)]),col='blue',lwd=2)
    legend('topright',legend = c('mDC cells','Non-mDC cells'),col=c('red','blue'),lwd=2)
    #4.4 mock facs plot: neutrophil/macrophage
    tmp=data.frame(`F4/80`=cytof_data[[i]]['PE-A<F4/80>',],`CD11b`=cytof_data[[i]]['BV605-A<CD11b>',],
                   labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    tmp$col='gray';tmp$col[tmp$labels=='Macrophages']='salmon';tmp$col[tmp$labels=='Neutrophils']='lightskyblue'
    tmp=tmp[tmp$col!='gray',]
    plot(x=tmp$CD11b,y=tmp$F4.80,pch=16,xlab='BV605-A<CD11b>',ylab='PE-A<F4/80>',cex=0.6,col=tmp$col,main=paste('Neutrophils/Macrophages:','mice',i,name))
    legend('topleft',legend=c('Macrophages','Neutrophils'),col=c('salmon','lightskyblue'),pch=16,cex=0.6)
    #4.45 mock facs plot: neutrophil/macrophage
    tmp=data.frame(`F4/80`=cytof_data[[i]]['PE-A<F4/80>',],`CD4`=cytof_data[[i]]['BV785-A<CD4>',],
                   labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    tmp$col='gray';tmp$col[tmp$labels=='Macrophages']='salmon';tmp$col[tmp$labels=='Neutrophils']='lightskyblue'
    tmp=tmp[tmp$col!='gray',]
    plot(x=tmp$F4.80,y=tmp$CD4,pch=16,xlab='PE-A<F4/80>',ylab='BV785-A<CD4>',cex=0.6,col=tmp$col,main=paste('Neutrophils/Macrophages:','mice',i,name))
    legend('topleft',legend=c('Macrophages','Neutrophils'),col=c('salmon','lightskyblue'),pch=16,cex=0.6)
    #4.5 mock facs plot: T cells/B cells
    tmp=data.frame(`CD3`=cytof_data[[i]]["FITC-A<CD3>",],`CD45R`=cytof_data[[i]]["Alexa Fluor 700-A<CD45R>",],
                   labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    tmp$col='gray';tmp$col[grepl('T cells',tmp$labels)]='salmon';tmp$col[tmp$labels=='B1 cells'|tmp$labels=='B2 cells']='lightskyblue'
    plot(x=tmp$CD3,y=tmp$CD45R,pch=16,xlab="FITC-A<CD3>",ylab="Alexa Fluor 700-A<CD45R>",cex=0.6,col=tmp$col,main=paste('T Cells/B cells:','mice',i,name))
    legend('topleft',legend=c('T cells','B cells','Others'),col=c('salmon','lightskyblue','gray'),pch=16,cex=0.6)
    #4.6 mock facs plot: CD8 T cells/CD4 T cells
    tmp=data.frame(`CD4`=cytof_data[[i]]["BV785-A<CD4>",],`CD8`=cytof_data[[i]]["BV510-A<CD8>" ,],
                   labels=results$scena1full[[i]]$cell_labels,stringsAsFactors = F)
    tmp$col='gray';tmp$col[grepl('CD8 T cells',tmp$labels)]='salmon';tmp$col[grepl('CD4 T cells',tmp$labels)]='lightskyblue';tmp$col[grepl('NK',tmp$labels)]='navy'
    tmp=tmp[tmp$col=='salmon'|tmp$col=='lightskyblue',]
    plot(x=tmp$CD4,y=tmp$CD8,pch=16,xlab="BV785-A<CD4>",ylab="BV510-A<CD8>",cex=0.6,col=tmp$col,main=paste('CD8 T cells/CD4 T cells:','mice',i,name))
    legend('topleft',legend=c('CD8 T cells','CD4 T cells'),col=c('salmon','lightskyblue' ),pch=16,cex=0.6)
  }
  dev.off()
}
#a temp test for mDC
# ind=which(test$scena1full[[3]]$cell_labels=='mDC')
# name='Stk4'
# i=6 #test the third mouse
# pdf('~/temp/testmDC.pdf',height=8,width = 10)
# tmp=data.frame(facs=cytof_mice$facs[[i]]['BV711-A<CD11c>',],labels=test$scena1full[[i]]$cell_labels,stringsAsFactors = F)
# boxplot(facs~labels,data=tmp,col=rainbow(10))
# legend('bottomright',legend=unique(tmp$labels)[order(unique(tmp$labels))],fill=rainbow(10),cex=0.5)
# tmp=tmp[grepl('B1',tmp$labels)|grepl('mDC cells',tmp$labels)|grepl('B2',tmp$labels)|grepl('CD4',tmp$labels),]
# plot(density(tmp$facs[grepl('mDC',tmp$labels)]),xlab='BV711-A<CD11c>',ylim=c(0,1),ylab='Frequency',col='red',lwd=2,main=paste('mDC cells:','mice',i,name))
# lines(density(tmp$facs[!grepl('mDC',tmp$labels)]),col='blue',lwd=2)
# legend('topright',legend = c('mDC cells','Non-mDC cells'),col=c('red','blue'),lwd=2)
# 
# dev.off()

